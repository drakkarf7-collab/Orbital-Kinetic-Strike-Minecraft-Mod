package fr.orbitalstrike.block;

import com.mojang.serialization.MapCodec;
import fr.orbitalstrike.registry.ModSounds;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2746;
import net.minecraft.class_5819;

/**
 * Tungsten Block. The SPIRE property marks the tip of the spire
 * left at the center of a crater, causing it to hum softly.
 */
public class TungstenBlock extends class_2248 {
    public static final MapCodec<TungstenBlock> CODEC = method_54094(TungstenBlock::new);
    public static final class_2746 SPIRE = class_2746.method_11825("spire");

    public TungstenBlock(class_2251 settings) {
        super(settings);
        method_9590(method_9595().method_11664().method_11657(SPIRE, false));
    }

    @Override
    protected MapCodec<? extends class_2248> method_53969() {
        return field_46280;
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(SPIRE);
    }

    @Override
    public void method_9496(class_2680 state, class_1937 world, class_2338 pos, class_5819 random) {
        if (state.method_11654(SPIRE) && random.method_43048(4) == 0) {
            world.method_8486(pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5,
                    ModSounds.HUM, net.minecraft.class_3419.field_15245, 0.6f, 0.9f + random.method_43057() * 0.2f, false);
        }
    }
}
