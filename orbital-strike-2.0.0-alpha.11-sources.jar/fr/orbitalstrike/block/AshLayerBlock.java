package fr.orbitalstrike.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2758;
import net.minecraft.class_3726;
import net.minecraft.class_4538;

/**
 * Ash layer deposited by the strike around the crater.
 * Stacks from 1 to 8 layers like snow, but does not melt.
 */
public class AshLayerBlock extends class_2248 {
    public static final MapCodec<AshLayerBlock> CODEC = method_54094(AshLayerBlock::new);
    public static final class_2758 LAYERS = class_2741.field_12536;
    private static final class_265[] SHAPES = new class_265[9];

    static {
        SHAPES[0] = class_259.method_1073();
        for (int i = 1; i <= 8; i++) SHAPES[i] = class_2248.method_9541(0, 0, 0, 16, i * 2, 16);
    }

    public AshLayerBlock(class_2251 settings) {
        super(settings);
        method_9590(method_9595().method_11664().method_11657(LAYERS, 1));
    }

    @Override
    protected MapCodec<? extends class_2248> method_53969() {
        return field_46280;
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(LAYERS);
    }

    @Override
    protected class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return SHAPES[state.method_11654(LAYERS)];
    }

    @Override
    protected class_265 method_9549(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return SHAPES[state.method_11654(LAYERS) - 1];
    }

    @Override
    protected boolean method_9558(class_2680 state, class_4538 world, class_2338 pos) {
        class_2338 below = pos.method_10074();
        class_2680 support = world.method_8320(below);
        return support.method_27852(this) && support.method_11654(LAYERS) == 8
                || class_2248.method_9501(support.method_26220(world, below), class_2350.field_11036);
    }

    @Override
    protected class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState,
                                                   class_1936 world, class_2338 pos, class_2338 neighborPos) {
        return !state.method_26184(world, pos) ? class_2246.field_10124.method_9564()
                : super.method_9559(state, direction, neighborState, world, pos, neighborPos);
    }

    @Override
    protected boolean method_9616(class_2680 state, class_1750 context) {
        int layers = state.method_11654(LAYERS);
        if (context.method_8041().method_31574(method_8389()) && layers < 8) {
            return !context.method_7717() || context.method_8038() == class_2350.field_11036;
        }
        return layers == 1;
    }

    @Override
    public class_2680 method_9605(class_1750 ctx) {
        class_2680 existing = ctx.method_8045().method_8320(ctx.method_8037());
        if (existing.method_27852(this)) return existing.method_11657(LAYERS, Math.min(8, existing.method_11654(LAYERS) + 1));
        return super.method_9605(ctx);
    }
}
