package fr.orbitalstrike.block;

import com.mojang.serialization.MapCodec;
import fr.orbitalstrike.config.ConfigManager;
import fr.orbitalstrike.registry.ModParticles;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2398;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2758;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5819;

/**
 * Molten rock left at the bottom of the crater. Transitions through 4 stages:
 * 0 molten, 1 incandescent, 2 hot, 3 cooled, then becomes basalt,
 * blackstone, or obsidian depending on its position.
 * Burns entities that step on it, melts nearby snow, and steams in the rain.
 */
public class MoltenRockBlock extends class_2248 {
    public static final MapCodec<MoltenRockBlock> CODEC = method_54094(MoltenRockBlock::new);
    public static final int MAX_STAGE = 3;
    public static final class_2758 STAGE = class_2758.method_11867("stage", 0, MAX_STAGE);

    private static final int[] LUMINANCE = {15, 12, 8, 0};
    private static final float[] STEP_DAMAGE = {4.0f, 2.0f, 1.0f, 0.0f};
    /** Fraction of total cooling duration spent in each stage. */
    private static final double[] STAGE_SHARE = {0.30, 0.30, 0.30, 0.10};

    public MoltenRockBlock(class_2251 settings) {
        super(settings);
        method_9590(method_9595().method_11664().method_11657(STAGE, 0));
    }

    @Override
    protected MapCodec<? extends class_2248> method_53969() {
        return field_46280;
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(STAGE);
    }

    public static int luminance(class_2680 state) {
        return LUMINANCE[state.method_11654(STAGE)];
    }

    /** Stage duration in ticks, with ±25% random jitter so cooling is non-uniform. */
    public static int stageTicks(int stage, class_5819 random) {
        double total = ConfigManager.get().moltenCoolingMinutes * 60.0 * 20.0;
        double jitter = 0.75 + 0.5 * random.method_43058();
        return Math.max(20, (int) (total * STAGE_SHARE[stage] * jitter));
    }

    @Override
    protected void method_9615(class_2680 state, class_1937 world, class_2338 pos, class_2680 oldState, boolean notify) {
        if (!world.field_9236 && !oldState.method_27852(this)) {
            world.method_39279(pos, this, stageTicks(state.method_11654(STAGE), world.method_8409()));
        }
    }

    @Override
    protected void method_9588(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
        int stage = state.method_11654(STAGE);
        meltAround(world, pos);
        if (stage < MAX_STAGE) {
            world.method_8652(pos, state.method_11657(STAGE, stage + 1), class_2248.field_31036);
            world.method_39279(pos, this, stageTicks(stage + 1, random));
        } else {
            world.method_8652(pos, cooledState(pos), class_2248.field_31036);
        }
    }

    /** Final block, chosen deterministically by position. */
    public static class_2680 cooledState(class_2338 pos) {
        int roll = Math.floorMod(pos.method_10263() * 73428767 ^ pos.method_10264() * 9127187 ^ pos.method_10260() * 19349663, 10);
        if (roll < 5) return class_2246.field_22091.method_9564();
        if (roll < 8) return class_2246.field_23869.method_9564();
        return class_2246.field_10540.method_9564();
    }

    private static void meltAround(class_3218 world, class_2338 pos) {
        for (class_2350 dir : class_2350.values()) {
            if (dir == class_2350.field_11033) continue;
            class_2338 p = pos.method_10093(dir);
            class_2680 s = world.method_8320(p);
            if (s.method_27852(class_2246.field_10477) || s.method_27852(class_2246.field_10491) || s.method_27852(class_2246.field_27879)) {
                world.method_8501(p, class_2246.field_10124.method_9564());
            } else if (s.method_27852(class_2246.field_10295) || s.method_27852(class_2246.field_10110)) {
                world.method_8501(p, class_2246.field_10382.method_9564());
            }
        }
    }

    /** Organic gradual cooling (without saturating the server scheduler) + steam in the rain. */
    @Override
    protected void method_9514(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
        int stage = state.method_11654(STAGE);
        if (world.method_8520(pos.method_10084()) && stage < MAX_STAGE) {
            world.method_14199(class_2398.field_11204, pos.method_10263() + 0.5, pos.method_10264() + 1.1, pos.method_10260() + 0.5,
                    4, 0.25, 0.1, 0.25, 0.02);
            world.method_8396(null, pos, class_3417.field_15102, class_3419.field_15245, 0.35f,
                    1.6f + random.method_43057() * 0.6f);
        }
        double totalSeconds = Math.max(30.0, ConfigManager.get().moltenCoolingMinutes * 60.0);
        // A block receives an average of 1 randomTick every ~68.27s (at randomTickSpeed = 3).
        double chance = Math.min(1.0, 68.27 / (totalSeconds * STAGE_SHARE[stage]));
        if (random.method_43058() < chance) {
            meltAround(world, pos);
            if (stage < MAX_STAGE) {
                world.method_8652(pos, state.method_11657(STAGE, stage + 1), class_2248.field_31036);
            } else {
                world.method_8652(pos, cooledState(pos), class_2248.field_31036);
            }
        }
    }

    @Override
    public void method_9591(class_1937 world, class_2338 pos, class_2680 state, class_1297 entity) {
        float damage = STEP_DAMAGE[state.method_11654(STAGE)];
        if (!world.field_9236 && damage > 0 && !entity.method_21749() && entity instanceof class_1309) {
            entity.method_5643(world.method_48963().method_48820(), damage);
            if (state.method_11654(STAGE) == 0) entity.method_5639(3);
        }
        super.method_9591(world, pos, state, entity);
    }

    @Override
    public void method_9496(class_2680 state, class_1937 world, class_2338 pos, class_5819 random) {
        int stage = state.method_11654(STAGE);
        if (stage >= MAX_STAGE || !world.method_8320(pos.method_10084()).method_26215()) return;
        if (random.method_43048(2 + stage * 3) == 0) {
            world.method_8406(ModParticles.EMBER, pos.method_10263() + random.method_43058(), pos.method_10264() + 1.02,
                    pos.method_10260() + random.method_43058(), 0, 0.03, 0);
        }
        if (stage == 0 && random.method_43048(40) == 0) {
            world.method_8486(pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5, class_3417.field_14576,
                    class_3419.field_15245, 0.3f, 0.7f + random.method_43057() * 0.3f, false);
        }
    }
}
