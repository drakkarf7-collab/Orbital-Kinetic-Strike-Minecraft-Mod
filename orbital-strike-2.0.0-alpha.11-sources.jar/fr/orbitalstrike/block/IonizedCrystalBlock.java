package fr.orbitalstrike.block;

import com.mojang.serialization.MapCodec;
import fr.orbitalstrike.registry.ModParticles;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3726;
import net.minecraft.class_5819;

/**
 * Sapphire-blue ionized crystal formed by plasma crystallization around the crater and spire.
 */
public class IonizedCrystalBlock extends class_2248 {
    public static final MapCodec<IonizedCrystalBlock> CODEC = method_54094(IonizedCrystalBlock::new);
    private static final class_265 SHAPE = class_2248.method_9541(3.0, 0.0, 3.0, 13.0, 14.0, 13.0);

    public IonizedCrystalBlock(class_2251 settings) {
        super(settings);
    }

    @Override
    protected MapCodec<? extends class_2248> method_53969() {
        return field_46280;
    }

    @Override
    protected class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return SHAPE;
    }

    @Override
    public void method_9496(class_2680 state, class_1937 world, class_2338 pos, class_5819 random) {
        if (random.method_43048(4) == 0) {
            world.method_8406(ModParticles.EMBER,
                    pos.method_10263() + 0.3 + random.method_43058() * 0.4,
                    pos.method_10264() + 0.4 + random.method_43058() * 0.5,
                    pos.method_10260() + 0.3 + random.method_43058() * 0.4,
                    (random.method_43058() - 0.5) * 0.015,
                    0.025 + random.method_43058() * 0.02,
                    (random.method_43058() - 0.5) * 0.015);
        }
    }
}
