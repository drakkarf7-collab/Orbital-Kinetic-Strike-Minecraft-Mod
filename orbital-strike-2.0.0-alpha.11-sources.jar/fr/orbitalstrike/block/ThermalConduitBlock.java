package fr.orbitalstrike.block;

import com.mojang.serialization.MapCodec;
import fr.orbitalstrike.config.ConfigManager;
import fr.orbitalstrike.registry.ModBlocks;
import fr.orbitalstrike.registry.ModParticles;
import java.util.Map;
import java.util.function.Function;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1750;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_3218;
import net.minecraft.class_5819;

/**
 * Thermal Conduit: sapphire-blue plasma seams along the edges and rings
 * of the tungsten spire, with 6 boolean properties for connected borders.
 */
public class ThermalConduitBlock extends class_2248 {
    public static final MapCodec<ThermalConduitBlock> CODEC = method_54094(ThermalConduitBlock::new);

    public static final class_2746 NORTH = class_2741.field_12489;
    public static final class_2746 SOUTH = class_2741.field_12540;
    public static final class_2746 EAST = class_2741.field_12487;
    public static final class_2746 WEST = class_2741.field_12527;
    public static final class_2746 UP = class_2741.field_12519;
    public static final class_2746 DOWN = class_2741.field_12546;

    public static final Map<class_2350, class_2746> FACING_PROPERTIES = Map.of(
            class_2350.field_11043, NORTH,
            class_2350.field_11035, SOUTH,
            class_2350.field_11034, EAST,
            class_2350.field_11039, WEST,
            class_2350.field_11036, UP,
            class_2350.field_11033, DOWN
    );

    public ThermalConduitBlock(class_2251 settings) {
        super(settings);
        class_2680 state = method_9595().method_11664();
        for (class_2746 prop : FACING_PROPERTIES.values()) {
            state = state.method_11657(prop, false);
        }
        method_9590(state);
    }

    @Override
    protected MapCodec<? extends class_2248> method_53969() {
        return field_46280;
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(NORTH, SOUTH, EAST, WEST, UP, DOWN);
    }

    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return connectSeams(method_9564(), ctx.method_8037(), ctx.method_8045()::method_8320);
    }

    @Override
    protected class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState,
                                                  class_1936 world, class_2338 pos, class_2338 neighborPos) {
        class_2746 prop = FACING_PROPERTIES.get(direction);
        return prop != null ? state.method_11657(prop, neighborState.method_27852(this)) : state;
    }

    /** Connects cardinal properties based on adjacent conduits (used by ImpactCraterGenerator). */
    public static class_2680 connectSeams(class_2680 state, class_2338 pos, Function<class_2338, class_2680> stateAt) {
        if (!(state.method_26204() instanceof ThermalConduitBlock)) return state;
        for (Map.Entry<class_2350, class_2746> entry : FACING_PROPERTIES.entrySet()) {
            state = state.method_11657(entry.getValue(), stateAt.apply(pos.method_10093(entry.getKey())).method_27852(state.method_26204()));
        }
        return state;
    }

    public static int decayTicks() {
        return ConfigManager.get().thermalConduitDecayMinutes * 60 * 20;
    }

    @Override
    protected void method_9615(class_2680 state, class_1937 world, class_2338 pos, class_2680 oldState, boolean notify) {
        if (!world.field_9236 && !oldState.method_27852(this)) {
            int decay = decayTicks();
            if (decay > 0) {
                world.method_39279(pos, this, decay);
            }
        }
    }

    @Override
    protected void method_9588(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
        // Conduits attached to the tungsten spire remain permanently incandescent.
        for (class_2350 dir : class_2350.values()) {
            if (world.method_8320(pos.method_10093(dir)).method_27852(ModBlocks.TUNGSTEN_BLOCK)) {
                return;
            }
        }
        world.method_8501(pos, class_2246.field_22091.method_9564());
    }

    @Override
    public void method_9591(class_1937 world, class_2338 pos, class_2680 state, class_1297 entity) {
        if (!world.field_9236 && !entity.method_21749() && entity instanceof class_1309) {
            entity.method_5643(world.method_48963().method_48820(), 2.0f);
        }
        super.method_9591(world, pos, state, entity);
    }

    @Override
    public void method_9496(class_2680 state, class_1937 world, class_2338 pos, class_5819 random) {
        if (random.method_43048(3) == 0 && world.method_8320(pos.method_10084()).method_26215()) {
            world.method_8406(ModParticles.EMBER, pos.method_10263() + random.method_43058(), pos.method_10264() + 1.02,
                    pos.method_10260() + random.method_43058(), 0, 0.03, 0);
        }
    }
}
