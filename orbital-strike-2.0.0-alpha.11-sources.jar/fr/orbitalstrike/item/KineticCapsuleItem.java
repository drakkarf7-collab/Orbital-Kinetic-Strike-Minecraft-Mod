package fr.orbitalstrike.item;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;

/**
 * Ionized Kinetic Capsule: miniaturized tungsten core used to assemble the Orbital Detonator.
 */
public class KineticCapsuleItem extends class_1792 {
    public KineticCapsuleItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public void method_7851(class_1799 stack, class_9635 context, List<class_2561> tooltip, class_1836 type) {
        tooltip.add(class_2561.method_43471("item.orbital_strike.kinetic_capsule.lore")
                .method_27695(class_124.field_1075, class_124.field_1056));
    }
}
