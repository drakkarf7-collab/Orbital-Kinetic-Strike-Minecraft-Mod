package fr.orbitalstrike.item;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;

/**
 * Orbital Detonator: when held, right-clicking strikes the aimed point (handled client-side by
 * TargetingController; the request is validated on the server).
 */
public class OrbitalDetonatorItem extends class_1792 {
    public OrbitalDetonatorItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public void method_7851(class_1799 stack, class_9635 context, List<class_2561> tooltip, class_1836 type) {
        tooltip.add(class_2561.method_43471("item.orbital_strike.orbital_detonator.lore").method_27695(class_124.field_1080, class_124.field_1056));
        tooltip.add(class_2561.method_43471("item.orbital_strike.orbital_detonator.use").method_27692(class_124.field_1075));
        tooltip.add(class_2561.method_43469("item.orbital_strike.orbital_detonator.hint",
                class_2561.method_43472("key.orbital_strike.menu").method_27692(class_124.field_1078)).method_27692(class_124.field_1063));
    }

    @Override
    public boolean method_7886(class_1799 stack) {
        return false;
    }
}
