package fr.orbitalstrike.strike;

import fr.orbitalstrike.crater.CraterProfile;
import java.util.Random;
import net.minecraft.class_1299;
import net.minecraft.class_1540;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2512;
import net.minecraft.class_2680;
import net.minecraft.class_2902;
import net.minecraft.class_3218;
import net.minecraft.class_3532;

/**
 * Ejecta: debris blocks launched along ballistic arcs on impact.
 * Uses vanilla falling block entities (visible even without a client-side mod),
 * configured to disappear on landing so ground material comes only from the
 * crater's ejecta blanket, keeping undo restoration exact.
 */
public final class Ejecta {
    private static final class_2680[] DEBRIS = {
            class_2246.field_27165.method_9564(), class_2246.field_10445.method_9564(), class_2246.field_23869.method_9564(),
            class_2246.field_10092.method_9564(), class_2246.field_22091.method_9564(), class_2246.field_10253.method_9564()
    };
    private static final double MIN_SPEED = 0.55, EXTRA_SPEED = 0.25;
    private static final double MIN_LIFT = 0.9, EXTRA_LIFT = 0.9;

    private Ejecta() {}

    /** Spawns at most {@code max} debris blocks around {@code target}, deterministically from the seed. */
    public static void spawn(class_3218 world, class_2338 target, int power, int max, long seed) {
        if (max <= 0) return;
        Random r = new Random(seed);
        int radius = CraterProfile.forPower(power).radius();
        int count = Math.min(max, 12 + power * 12);
        for (int i = 0; i < count; i++) {
            double angle = r.nextDouble() * Math.PI * 2;
            double dist = radius * (0.15 + 0.5 * r.nextDouble());
            int x = class_3532.method_15357(target.method_10263() + 0.5 + Math.cos(angle) * dist);
            int z = class_3532.method_15357(target.method_10260() + 0.5 + Math.sin(angle) * dist);
            if (!world.method_8393(x >> 4, z >> 4)) continue;
            int y = world.method_8624(class_2902.class_2903.field_13202, x, z) + 1;

            class_1540 e = class_1299.field_6089.method_5883(world);
            if (e == null) return;
            class_2487 nbt = new class_2487();
            nbt.method_10566("BlockState", class_2512.method_10686(DEBRIS[r.nextInt(DEBRIS.length)]));
            nbt.method_10569("Time", 1);
            nbt.method_10556("DropItem", false);
            nbt.method_10556("CancelDrop", true); // disappears on landing without placing a block
            e.method_5651(nbt);
            e.method_5808(x + 0.5, y, z + 0.5, 0, 0);
            double speed = MIN_SPEED + r.nextDouble() * (0.45 + EXTRA_SPEED * power);
            double lift = MIN_LIFT + r.nextDouble() * EXTRA_LIFT;
            e.method_18800(Math.cos(angle) * speed, lift, Math.sin(angle) * speed);
            world.method_8649(e);
        }
    }
}
