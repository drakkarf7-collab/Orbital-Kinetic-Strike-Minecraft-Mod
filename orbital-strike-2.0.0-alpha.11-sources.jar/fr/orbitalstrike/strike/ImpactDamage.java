package fr.orbitalstrike.strike;

import fr.orbitalstrike.config.ModConfig;
import fr.orbitalstrike.registry.ModDamageTypes;
import org.jetbrains.annotations.Nullable;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3218;

/**
 * Strike damage: core impact at the center, followed by an expanding shockwave.
 * A UUID set ensures each entity is hit at most once by the shockwave.
 */
public final class ImpactDamage {
    private final class_3218 world;
    private final class_243 center;
    private final double radius;
    private final @Nullable class_1297 attacker;
    private final ModConfig cfg;
    private final Set<UUID> waveHit = new HashSet<>();
    private double lastWaveRadius;

    public ImpactDamage(class_3218 world, class_243 center, double radius, @Nullable class_1297 attacker, ModConfig cfg) {
        this.world = world;
        this.center = center;
        this.radius = radius;
        this.attacker = attacker;
        this.cfg = cfg;
        this.lastWaveRadius = radius;
    }

    public double waveEndRadius() {
        return radius * 2.5;
    }

    /** Impact core: massive damage and destruction of dropped items. */
    public void core() {
        class_238 box = new class_238(center, center).method_1009(radius, radius + 64, radius);
        for (class_1297 e : world.method_8335(null, box)) {
            if (horizontalDistance(e) > radius) continue;
            if (e instanceof class_1542) {
                e.method_31472();
                continue;
            }
            if (!canAffect(e)) continue;
            e.method_5643(ModDamageTypes.source(world, ModDamageTypes.KINETIC_IMPACT, attacker), cfg.impactDamage);
            waveHit.add(e.method_5667());
        }
    }

    /** Progressive shockwave front damage up to {@code waveRadius}. */
    public void waveAtRadius(double waveRadius) {
        if (waveRadius <= radius) return;
        double progress = (waveRadius - radius) / Math.max(1.0, waveEndRadius() - radius);
        wave(Math.min(1.0, progress));
    }

    /** Shockwave sweep: progress from 0 to 1 over the phase duration. */
    public void wave(double progress) {
        double current = radius + Math.min(1.0, progress) * (waveEndRadius() - radius);
        if (current <= lastWaveRadius) return;
        class_238 box = new class_238(center, center).method_1009(current, 48, current);
        for (class_1297 e : world.method_8335(null, box)) {
            if (!(e instanceof class_1309 living) || !canAffect(e)) continue;
            double d = horizontalDistance(e);
            if (d > current || d < lastWaveRadius - 1 || !waveHit.add(e.method_5667())) continue;

            double falloff = 1.0 - (d - radius) / (waveEndRadius() - radius);
            float dmg = (float) (cfg.shockwaveDamage * Math.max(0.15, falloff));
            e.method_5643(ModDamageTypes.source(world, ModDamageTypes.SHOCKWAVE, attacker), dmg);

            class_243 dir = new class_243(e.method_23317() - center.field_1352, 0, e.method_23321() - center.field_1350);
            dir = dir.method_1027() < 1e-4 ? new class_243(1, 0, 0) : dir.method_1029();
            double push = 1.2 + 2.0 * Math.max(0, falloff);
            e.method_5762(dir.field_1352 * push, 0.5 + 0.4 * falloff, dir.field_1350 * push);
            e.field_6037 = true;
            living.method_6092(new class_1293(class_1294.field_5909, 100, 1));
            living.method_6092(new class_1293(class_1294.field_5916, 100, 0));
        }
        lastWaveRadius = current;
    }

    private boolean canAffect(class_1297 e) {
        if (e instanceof class_1657 p) {
            if (!cfg.affectPlayers && p != attacker) return false;
            return !p.method_7325();
        }
        return true;
    }

    private double horizontalDistance(class_1297 e) {
        double dx = e.method_23317() - center.field_1352, dz = e.method_23321() - center.field_1350;
        return Math.sqrt(dx * dx + dz * dz);
    }
}
