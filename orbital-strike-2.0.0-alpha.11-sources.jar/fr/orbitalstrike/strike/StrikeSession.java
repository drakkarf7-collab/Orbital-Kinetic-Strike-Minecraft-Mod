package fr.orbitalstrike.strike;

import fr.orbitalstrike.config.ConfigManager;
import fr.orbitalstrike.config.ModConfig;
import fr.orbitalstrike.crater.ImpactCraterGenerator;
import fr.orbitalstrike.crater.UndoSnapshot;
import fr.orbitalstrike.crater.UndoStore;
import fr.orbitalstrike.network.Payloads;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import org.jetbrains.annotations.Nullable;

/**
 * Server-side execution of an orbital strike:
 * steps through {@link StrikeTimeline} phases, broadcasts phase and effect packets
 * ({@link Payloads.Phase}, {@link Payloads.SkyStreak}, {@link Payloads.Impact}, {@link Payloads.Shockwave})
 * to nearby players, then carves the crater and syncs chunks within a per-tick budget.
 */
public final class StrikeSession {
    private static final double MIN_NOTIFY_RANGE = 512.0;
    private static final int CHUNK_SYNC_PER_TICK = 36;
    private static final double STREAK_ENTRY_HEIGHT = 480.0;

    final java.util.UUID strikeId;
    final @Nullable java.util.UUID owner;
    final class_3218 world;
    final class_2338 target;
    final int power;
    final StrikeTimeline timeline;
    final float speed;
    final long seed;
    final ModConfig cfg = ConfigManager.get();

    private int entryIndex = 0;
    private int phaseElapsed = 0;
    private boolean phaseEntered = false;
    private boolean done = false;
    private int shockwaveDuration = 1;
    private double shockwaveElapsed = 0.0;

    private @Nullable ImpactCraterGenerator crater;
    private @Nullable ImpactDamage damage;
    private @Nullable class_243 anchor;
    private boolean ownerCinematic;
    private StrikePhase phase = StrikePhase.MARK;

    StrikeSession(@Nullable class_3222 owner, class_3218 world, class_2338 target, int power,
                  StrikeTimeline timeline) {
        this(owner, world, target, power, timeline, 1.0f, CinematicMode.FULL);
    }

    StrikeSession(@Nullable class_3222 owner, class_3218 world, class_2338 target, int power,
                  StrikeTimeline timeline, float speed, CinematicMode mode) {
        this.strikeId = java.util.UUID.randomUUID();
        this.owner = owner == null ? null : owner.method_5667();
        this.world = world;
        this.target = target;
        this.power = power;
        this.timeline = timeline;
        this.speed = StrikeTimeline.clampSpeed(speed);
        this.seed = world.method_8409().method_43055();
        this.ownerCinematic = owner != null && mode != CinematicMode.OFF;
    }

    public StrikePhase phase() {
        return phase;
    }

    boolean inCinematic() {
        return ownerCinematic && !done && (phase.cinematic || phase == StrikePhase.MARK
                || phase == StrikePhase.COUNTDOWN || phase == StrikePhase.STREAK || phase == StrikePhase.HUSH);
    }

    /** Advances the strike sequence by one server tick. Returns false once everything is complete. */
    boolean tick() {
        class_3222 ownerPlayer = ownerPlayer();
        if (ownerCinematic && ownerPlayer == null) {
            ownerCinematic = false;
        }
        if (inCinematic() && ownerPlayer != null) {
            holdOwner(ownerPlayer);
        }

        if (!done) {
            advanceTimeline();
        }
        stepCrater();

        return !done || (crater != null && (!crater.isDone() || crater.hasPendingSync()));
    }

    private void advanceTimeline() {
        if (entryIndex >= timeline.size()) {
            phase = StrikePhase.DONE;
            done = true;
            return;
        }

        StrikeTimeline.Entry entry = timeline.get(entryIndex);
        if (!phaseEntered) {
            enterPhase(entry);
            phaseEntered = true;
            phaseElapsed = 0;
        }

        phaseElapsed++;
        if (phase == StrikePhase.SHOCKWAVE) {
            shockwaveElapsed = phaseElapsed;
            if (damage != null && (phaseElapsed % 2 == 0 || phaseElapsed >= entry.ticks())) {
                double scale = powerScale();
                double waveR = ImpactCraterGenerator.shockwaveRadius(shockwaveElapsed, shockwaveDuration, 400.0 * scale);
                damage.waveAtRadius(waveR);
            }
        }

        boolean finishedPhase;
        if (entry.phase() == StrikePhase.SETTLE || entry.ticks() <= 0) {
            finishedPhase = crater == null || (crater.isDone() && !crater.hasPendingSync());
        } else {
            finishedPhase = phaseElapsed >= entry.ticks();
        }

        if (finishedPhase) {
            entryIndex++;
            phaseEntered = false;
            if (entryIndex >= timeline.size()) {
                phase = StrikePhase.DONE;
                done = true;
            }
        }
    }

    private void enterPhase(StrikeTimeline.Entry entry) {
        phase = entry.phase();
        broadcastPhase(phase, entry.ticks());

        double scale = powerScale();
        class_243 c = impactCenter();

        switch (phase) {
            case STREAK -> {
                // Purely vertical drop straight down from the zenith above the impact point.
                class_243 from = c.method_1031(0.0, STREAK_ENTRY_HEIGHT, 0.0);
                broadcast(new Payloads.SkyStreak(
                        strikeId, from.field_1352, from.field_1351, from.field_1350, c.field_1352, c.field_1351, c.field_1350, Math.max(1, entry.ticks())
                ));
            }
            case IMPACT -> doImpact();
            case SHOCKWAVE -> {
                shockwaveDuration = Math.max(1, entry.ticks());
                shockwaveElapsed = 0.0;
                broadcast(new Payloads.Shockwave(
                        strikeId, c.field_1352, c.field_1351, c.field_1350,
                        (float) (20.0 * scale), (float) (400.0 * scale), shockwaveDuration
                ));
            }
            default -> {}
        }
    }

    private void stepCrater() {
        if (crater == null) return;
        if (!crater.isDone()) {
            double scale = powerScale();
            double radiusLimit;
            if (phase == StrikePhase.SHOCKWAVE) {
                double waveR = ImpactCraterGenerator.shockwaveRadius(
                        Math.max(1.0, shockwaveElapsed), shockwaveDuration, crater.radius());
                radiusLimit = Math.max(0.0, Math.min(waveR + 24.0 * scale, crater.radius() + 24.0));
            } else {
                radiusLimit = crater.radius() + 32.0;
            }
            long budgetNanos = Math.max(cfg.craterMsPerTick * 3L, 22L) * 1_000_000L;
            crater.tickUpTo(radiusLimit, budgetNanos);
            if (crater.isDone()) {
                storeUndo();
            }
        }
        crater.flushChunkSync(CHUNK_SYNC_PER_TICK);
    }

    void flush() {
        if (crater != null && !crater.isDone()) {
            crater.finishNow();
            storeUndo();
        }
    }

    private void storeUndo() {
        if (crater != null && crater.snapshot() != null) {
            UndoStore.add(world.method_8503(), crater.snapshot());
        }
    }

    private void doImpact() {
        double scale = powerScale();
        double coreRadius = 160.0 * scale;
        double visualBasinRadius = 88.0 * scale;
        class_243 c = impactCenter();

        damage = new ImpactDamage(world, c, coreRadius, ownerPlayer(), cfg);
        damage.core();

        broadcast(new Payloads.Impact(strikeId, c.field_1352, c.field_1351, c.field_1350, (float) visualBasinRadius, power));

        if (cfg.terrainDestruction) {
            UndoSnapshot snapshot = cfg.undoMaxSnapshots > 0
                    ? new UndoSnapshot(strikeId, world.method_27983().method_29177(), target, power, System.currentTimeMillis())
                    : null;
            crater = new ImpactCraterGenerator(world, target, power, seed, cfg, snapshot);
            crater.impactBurst();
        }
        if (cfg.maxEjecta > 0) {
            Ejecta.spawn(world, target, power, cfg.maxEjecta, seed);
        }
    }

    private void broadcastPhase(StrikePhase p, int durationTicks) {
        double range = notifyRange();
        class_243 c = impactCenter();
        for (class_3222 pl : world.method_18456()) {
            boolean isOwner = pl.method_5667().equals(owner);
            if (!isOwner && pl.method_5707(c) > range * range) continue;
            if (!ServerPlayNetworking.canSend(pl, Payloads.Phase.ID)) continue;
            boolean cinematic = isOwner ? ownerCinematic : (ownerCinematic && cfg.showCinematicToNearbyPlayers);
            ServerPlayNetworking.send(pl, new Payloads.Phase(
                    strikeId, p.ordinal(), durationTicks, target, power, cinematic, isOwner
            ));
        }
    }

    private void broadcast(class_8710 payload) {
        double range = notifyRange();
        class_243 c = impactCenter();
        for (class_3222 pl : world.method_18456()) {
            boolean isOwner = pl.method_5667().equals(owner);
            if (!isOwner && pl.method_5707(c) > range * range) continue;
            if (!ServerPlayNetworking.canSend(pl, payload.method_56479())) continue;
            ServerPlayNetworking.send(pl, payload);
        }
    }

    private double powerScale() {
        return Math.max(0.25, power / 4.0);
    }

    private double notifyRange() {
        return Math.max(MIN_NOTIFY_RANGE, 400.0 * powerScale() * 2.5 + 200.0);
    }

    private void holdOwner(class_3222 p) {
        if (anchor == null) anchor = p.method_19538();
        p.method_18799(class_243.field_1353);
        p.field_6017 = 0;
        if (p.method_19538().method_1025(anchor) > 0.01) {
            p.field_13987.method_14363(anchor.field_1352, anchor.field_1351, anchor.field_1350, p.method_36454(), p.method_36455());
        }
    }

    private class_243 impactCenter() {
        return new class_243(target.method_10263() + 0.5, target.method_10264() + 1.0, target.method_10260() + 0.5);
    }

    private @Nullable class_3222 ownerPlayer() {
        if (owner == null) return null;
        var p = world.method_8503().method_3760().method_14602(owner);
        return p != null && p.method_51469() == world ? p : null;
    }
}
