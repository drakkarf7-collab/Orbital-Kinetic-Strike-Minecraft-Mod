package fr.orbitalstrike.registry;

import fr.orbitalstrike.OrbitalStrike;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_7923;

/** Creative mode tab for the mod. */
public final class ModItemGroup {
    public static final class_1761 GROUP = class_2378.method_10230(class_7923.field_44687, OrbitalStrike.id("main"),
            FabricItemGroup.builder()
                    .method_47320(() -> new class_1799(ModItems.ORBITAL_DETONATOR))
                    .method_47321(class_2561.method_43471("itemGroup.orbital_strike.main"))
                    .method_47317((ctx, entries) -> {
                        entries.method_45421(ModItems.ORBITAL_DETONATOR);
                        entries.method_45421(ModItems.KINETIC_CAPSULE);
                        entries.method_45421(ModBlocks.TUNGSTEN_BLOCK);
                        entries.method_45421(ModBlocks.THERMAL_CONDUIT);
                        entries.method_45421(ModBlocks.IONIZED_CRYSTAL);
                        entries.method_45421(ModBlocks.MOLTEN_ROCK);
                        entries.method_45421(ModBlocks.CHARRED_LOG);
                        entries.method_45421(ModBlocks.ASH_LAYER);
                    })
                    .method_47324());

    private ModItemGroup() {}

    public static void register() {}
}
