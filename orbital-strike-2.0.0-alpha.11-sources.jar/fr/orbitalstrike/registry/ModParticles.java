package fr.orbitalstrike.registry;

import fr.orbitalstrike.OrbitalStrike;
import net.fabricmc.fabric.api.particle.v1.FabricParticleTypes;
import net.minecraft.class_2378;
import net.minecraft.class_2400;
import net.minecraft.class_7923;

/** Particles: embers, ash, and rock debris. */
public final class ModParticles {
    public static final class_2400 EMBER = reg("ember");
    public static final class_2400 ASH = reg("ash");
    public static final class_2400 DEBRIS = reg("debris");

    private ModParticles() {}

    private static class_2400 reg(String name) {
        return class_2378.method_10230(class_7923.field_41180, OrbitalStrike.id(name), FabricParticleTypes.simple(true));
    }

    public static void register() {}
}
