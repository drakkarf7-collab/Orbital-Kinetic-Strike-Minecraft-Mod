package fr.orbitalstrike.registry;

import fr.orbitalstrike.OrbitalStrike;
import fr.orbitalstrike.block.AshLayerBlock;
import fr.orbitalstrike.block.MoltenRockBlock;
import fr.orbitalstrike.block.ThermalConduitBlock;
import fr.orbitalstrike.block.TungstenBlock;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2465;
import net.minecraft.class_2498;
import net.minecraft.class_3619;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_7923;

/** Mod blocks: tungsten, molten rock, thermal conduit, charred log, ash layer, and ionized crystal. */
public final class ModBlocks {
    public static final class_2248 TUNGSTEN_BLOCK = reg("tungsten_block", new TungstenBlock(class_4970.class_2251.method_9637()
            .method_31710(class_3620.field_15978)
            .method_9629(50.0f, 1200.0f)
            .method_29292()
            .method_9626(class_2498.field_22150)
            .method_50012(class_3619.field_15972)));

    public static final class_2248 THERMAL_CONDUIT = reg("thermal_conduit", new ThermalConduitBlock(class_4970.class_2251.method_9637()
            .method_31710(class_3620.field_15980)
            .method_9629(3.0f, 6.0f)
            .method_29292()
            .method_9631(state -> 15)
            .method_26249((state, world, pos) -> true)
            .method_9626(class_2498.field_22146)));

    public static final class_2248 MOLTEN_ROCK = reg("molten_rock", new MoltenRockBlock(class_4970.class_2251.method_9637()
            .method_31710(class_3620.field_25706)
            .method_9629(3.0f, 6.0f)
            .method_29292()
            .method_9640()
            .method_9631(MoltenRockBlock::luminance)
            .method_26249((state, world, pos) -> state.method_11654(MoltenRockBlock.STAGE) < MoltenRockBlock.MAX_STAGE)
            .method_9626(class_2498.field_22143)));

    public static final class_2248 CHARRED_LOG = reg("charred_log", new class_2465(class_4970.class_2251.method_9637()
            .method_31710(class_3620.field_16009)
            .method_9632(1.5f)
            .method_9626(class_2498.field_11547)));

    public static final class_2248 ASH_LAYER = reg("ash_layer", new AshLayerBlock(class_4970.class_2251.method_9637()
            .method_31710(class_3620.field_15978)
            .method_9632(0.1f)
            .method_51371()
            .method_50012(class_3619.field_15971)
            .method_9626(class_2498.field_11526)));

    public static final class_2248 IONIZED_CRYSTAL = reg("ionized_crystal", new fr.orbitalstrike.block.IonizedCrystalBlock(class_4970.class_2251.method_9637()
            .method_31710(class_3620.field_16024)
            .method_9629(1.8f, 4.0f)
            .method_29292()
            .method_22488()
            .method_9631(state -> 12)
            .method_26249((state, world, pos) -> true)
            .method_9626(class_2498.field_27198)));

    private ModBlocks() {}

    private static class_2248 reg(String name, class_2248 block) {
        var id = OrbitalStrike.id(name);
        class_2378.method_10230(class_7923.field_41175, id, block);
        class_2378.method_10230(class_7923.field_41178, id, new class_1747(block, new class_1792.class_1793().method_24359()));
        return block;
    }

    public static void register() {}
}
