package fr.orbitalstrike.registry;

import fr.orbitalstrike.OrbitalStrike;
import fr.orbitalstrike.item.OrbitalDetonatorItem;
import net.minecraft.class_1792;
import net.minecraft.class_1814;
import net.minecraft.class_2378;
import net.minecraft.class_7923;

/** Mod items. */
public final class ModItems {
    public static final class_1792 ORBITAL_DETONATOR = class_2378.method_10230(class_7923.field_41178, OrbitalStrike.id("orbital_detonator"),
            new OrbitalDetonatorItem(new class_1792.class_1793().method_7889(1).method_7894(class_1814.field_8904).method_24359()));

    public static final class_1792 KINETIC_CAPSULE = class_2378.method_10230(class_7923.field_41178, OrbitalStrike.id("kinetic_capsule"),
            new fr.orbitalstrike.item.KineticCapsuleItem(new class_1792.class_1793().method_7889(16).method_7894(class_1814.field_8903).method_24359()));

    private ModItems() {}

    public static void register() {}
}
