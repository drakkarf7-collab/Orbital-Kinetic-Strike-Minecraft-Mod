package fr.orbitalstrike.registry;

import fr.orbitalstrike.OrbitalStrike;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_7923;

/**
 * Custom sound events for Orbital Kinetic Strike.
 */
public final class ModSounds {

    public static final class_3414 MARK = register("mark");
    public static final class_3414 COUNTDOWN = register("countdown");
    public static final class_3414 ASCENT = register("ascent");
    public static final class_3414 TRANSFER = register("transfer");
    public static final class_3414 RING = register("ring");
    public static final class_3414 LOAD = register("load");
    public static final class_3414 SPIN = register("spin");
    public static final class_3414 RELEASE = register("release");
    public static final class_3414 FLIGHT = register("flight");
    public static final class_3414 STREAK = register("streak");
    public static final class_3414 HUSH = register("hush");
    public static final class_3414 CRACK = register("crack");
    public static final class_3414 BOOM = register("boom");
    public static final class_3414 WIND = register("wind");
    public static final class_3414 HUM = register("hum");

    private ModSounds() {}

    private static class_3414 register(String name) {
        class_2960 id = OrbitalStrike.id(name);
        return class_2378.method_10230(class_7923.field_41172, id, class_3414.method_47908(id));
    }

    public static void register() {}
}
