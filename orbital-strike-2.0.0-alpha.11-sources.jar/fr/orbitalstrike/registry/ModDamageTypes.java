package fr.orbitalstrike.registry;

import fr.orbitalstrike.OrbitalStrike;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_3218;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.class_8110;
import org.jetbrains.annotations.Nullable;

/** Damage types (defined in JSON under data/orbital_strike/damage_type). */
public final class ModDamageTypes {
    public static final class_5321<class_8110> KINETIC_IMPACT =
            class_5321.method_29179(class_7924.field_42534, OrbitalStrike.id("kinetic_impact"));
    public static final class_5321<class_8110> SHOCKWAVE =
            class_5321.method_29179(class_7924.field_42534, OrbitalStrike.id("shockwave"));

    private ModDamageTypes() {}

    public static class_1282 source(class_3218 world, class_5321<class_8110> key, @Nullable class_1297 attacker) {
        var entry = world.method_30349().method_30530(class_7924.field_42534).method_40290(key);
        return new class_1282(entry, attacker);
    }
}
