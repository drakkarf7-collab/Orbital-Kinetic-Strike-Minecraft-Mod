package fr.orbitalstrike.skill;

import fr.orbitalstrike.config.ModConfig;
import net.minecraft.class_2561;
import net.minecraft.class_2960;

/**
 * A skill usable from the selection menu.
 * To add a skill: implement this interface and register it in SkillRegistry.
 */
public interface Skill {
    class_2960 id();

    default class_2561 name() {
        return class_2561.method_43471("skill." + id().method_12836() + "." + id().method_12832());
    }

    default class_2561 description() {
        return class_2561.method_43471("skill." + id().method_12836() + "." + id().method_12832() + ".desc");
    }

    default class_2960 icon() {
        return class_2960.method_60655(id().method_12836(), "textures/gui/skill/" + id().method_12832() + ".png");
    }

    int cooldownTicks(ModConfig cfg);

    /** Checks range, cooldown, required item, and permissions. */
    ValidationResult validate(SkillContext ctx);

    /** Executes the skill (called only if validate() succeeded). */
    void execute(SkillContext ctx);

    record ValidationResult(boolean ok, class_2561 reason) {
        public static final ValidationResult OK = new ValidationResult(true, class_2561.method_43473());

        public static ValidationResult fail(String key, Object... args) {
            return new ValidationResult(false, class_2561.method_43469(key, args));
        }
    }
}
