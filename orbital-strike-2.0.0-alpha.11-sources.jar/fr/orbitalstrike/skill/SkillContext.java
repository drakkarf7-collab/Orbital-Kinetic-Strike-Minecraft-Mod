package fr.orbitalstrike.skill;

import fr.orbitalstrike.strike.CinematicMode;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import org.jetbrains.annotations.Nullable;

/**
 * Parameters for a skill invocation.
 * {@code player} may be null (strike triggered from server console via command).
 */
public record SkillContext(@Nullable class_3222 player, class_3218 world, class_2338 target, int power,
                           float speed, CinematicMode mode) {}
