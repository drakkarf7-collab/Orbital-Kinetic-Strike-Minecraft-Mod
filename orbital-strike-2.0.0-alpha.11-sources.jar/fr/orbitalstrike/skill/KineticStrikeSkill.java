package fr.orbitalstrike.skill;

import fr.orbitalstrike.OrbitalStrike;
import fr.orbitalstrike.config.ConfigManager;
import fr.orbitalstrike.config.ModConfig;
import fr.orbitalstrike.cooldown.CooldownStore;
import fr.orbitalstrike.registry.ModItems;
import fr.orbitalstrike.strike.StrikeManager;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

/** Kinetic Strike: tungsten rod launched from orbit. */
public final class KineticStrikeSkill implements Skill {
    public static final class_2960 ID = OrbitalStrike.id("kinetic_strike");

    @Override
    public class_2960 id() {
        return ID;
    }

    @Override
    public int cooldownTicks(ModConfig cfg) {
        return cfg.cooldownSeconds * 20;
    }

    @Override
    public ValidationResult validate(SkillContext ctx) {
        class_3222 player = ctx.player();
        if (player == null) return ValidationResult.OK;
        ModConfig cfg = ConfigManager.get();

        if (cfg.opOnly && !player.method_5687(2)) {
            return ValidationResult.fail("message.orbital_strike.no_permission");
        }
        if (!player.method_31548().method_7379(ModItems.ORBITAL_DETONATOR.method_7854())) {
            return ValidationResult.fail("message.orbital_strike.no_item");
        }
        if (StrikeManager.hasActive(player)) {
            return ValidationResult.fail("message.orbital_strike.already_active");
        }
        if (StrikeManager.activeCount() >= cfg.maxConcurrentStrikes) {
            return ValidationResult.fail("message.orbital_strike.too_many");
        }
        long global = StrikeManager.globalCooldownRemaining(ctx.world().method_8503());
        if (global > 0 && !player.method_5687(2)) {
            return ValidationResult.fail("message.orbital_strike.global_cooldown", (global + 19) / 20);
        }
        long remaining = CooldownStore.remaining(player, ID);
        if (remaining > 0) {
            return ValidationResult.fail("message.orbital_strike.cooldown", (remaining + 19) / 20);
        }
        if (player.method_51469() != ctx.world() || !ctx.world().method_24794(ctx.target())) {
            return ValidationResult.fail("message.orbital_strike.invalid_target");
        }
        // Small margin for network latency and client raycast rounding.
        class_243 eyes = player.method_33571();
        if (eyes.method_1022(class_243.method_24953(ctx.target())) > cfg.maxRange + 4) {
            return ValidationResult.fail("message.orbital_strike.too_far", cfg.maxRange);
        }
        if (!ctx.world().method_8393(ctx.target().method_10263() >> 4, ctx.target().method_10260() >> 4)) {
            return ValidationResult.fail("message.orbital_strike.invalid_target");
        }
        if (cfg.respectSpawnProtection && ctx.world().method_8503().method_3785(ctx.world(), ctx.target(), player)) {
            return ValidationResult.fail("message.orbital_strike.protected");
        }
        return ValidationResult.OK;
    }

    @Override
    public void execute(SkillContext ctx) {
        if (ctx.player() != null) {
            CooldownStore.start(ctx.player(), ID, cooldownTicks(ConfigManager.get()));
        }
        StrikeManager.start(ctx);
    }
}
