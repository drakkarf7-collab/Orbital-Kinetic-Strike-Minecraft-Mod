package fr.orbitalstrike.client.mixin;

import fr.orbitalstrike.OrbitalStrike;
import fr.orbitalstrike.client.fx.SoundDirector;
import fr.orbitalstrike.client.fx.SourceHandle;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Map;
import net.minecraft.class_1113;
import net.minecraft.class_1140;
import net.minecraft.class_4235;

/** Muffles all game sounds (except mod sounds) during the pre-impact hush. */
@Mixin(class_1140.class)
public abstract class SoundSystemMixin {
    @Shadow @Final private Map<class_1113, class_4235.class_4236> sources;

    @Inject(method = "getAdjustedVolume(Lnet/minecraft/client/sound/SoundInstance;)F", at = @At("RETURN"), cancellable = true)
    private void orbitalStrike$silence(class_1113 sound, CallbackInfoReturnable<Float> cir) {
        float m = SoundDirector.worldVolumeMultiplier();
        if (m >= 0.999f) return;
        if (OrbitalStrike.MOD_ID.equals(sound.method_4775().method_12836())) return;
        cir.setReturnValue(cir.getReturnValueF() * m);
    }

    @Inject(method = "play(Lnet/minecraft/client/sound/SoundInstance;)V", at = @At("TAIL"))
    private void orbitalStrike$exemptModSound(class_1113 sound, CallbackInfo ci) {
        if (sound != null && OrbitalStrike.MOD_ID.equals(sound.method_4775().method_12836())) {
            class_4235.class_4236 manager = this.sources.get(sound);
            if (manager != null) {
                manager.method_19735(source -> ((SourceHandle) source).orbitalStrike$exempt());
            }
        }
    }
}
