package fr.orbitalstrike.client.mixin;

import fr.orbitalstrike.client.fx.PostEffects;
import net.minecraft.class_757;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Applies mod post-processing effects right after world rendering, before the HUD. */
@Mixin(class_757.class)
public abstract class GameRendererMixin {
    @Inject(method = "render", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/render/WorldRenderer;drawEntityOutlinesFramebuffer()V", shift = At.Shift.AFTER))
    private void orbitalStrike$postEffects(class_9779 tickCounter, boolean tick, CallbackInfo ci) {
        PostEffects.render(tickCounter.method_60636());
    }
}
