package fr.orbitalstrike.client;

import fr.orbitalstrike.client.cinematic.CinematicDirector;
import fr.orbitalstrike.client.debug.CraterSyncTest;
import fr.orbitalstrike.client.debug.SelfTest;
import fr.orbitalstrike.client.fx.FxController;
import fr.orbitalstrike.client.fx.PostEffects;
import fr.orbitalstrike.client.cinematic.WorldCamera;
import fr.orbitalstrike.client.gui.DetonatorScreen;
import fr.orbitalstrike.client.particle.StrikeParticles;
import fr.orbitalstrike.client.render.world.WorldFx;
import fr.orbitalstrike.client.targeting.TargetingController;
import fr.orbitalstrike.network.Payloads;
import fr.orbitalstrike.registry.ModParticles;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3264;
import net.minecraft.class_3300;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

/** Client entry point: keybindings, networking, particles, HUD, effects. */
public final class OrbitalStrikeClient implements ClientModInitializer {
    public static class_304 menuKey;

    @Override
    public void onInitializeClient() {
        ClientConfig.load();

        menuKey = KeyBindingHelper.registerKeyBinding(new class_304("key.orbital_strike.menu",
                class_3675.class_307.field_1668, GLFW.GLFW_KEY_R, "key.category.orbital_strike"));

        ClientPlayNetworking.registerGlobalReceiver(Payloads.Phase.ID, (p, ctx) -> FxController.onPhase(p));
        ClientPlayNetworking.registerGlobalReceiver(Payloads.Impact.ID, (p, ctx) -> FxController.onImpact(p));
        ClientPlayNetworking.registerGlobalReceiver(Payloads.SkyStreak.ID, (p, ctx) -> FxController.onSkyStreak(p));
        ClientPlayNetworking.registerGlobalReceiver(Payloads.Shockwave.ID, (p, ctx) -> FxController.onShockwave(p));
        ClientPlayNetworking.registerGlobalReceiver(Payloads.CooldownSync.ID, (p, ctx) -> ClientState.onSync(p));

        net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap.INSTANCE.putBlock(
                fr.orbitalstrike.registry.ModBlocks.IONIZED_CRYSTAL,
                net.minecraft.class_1921.method_23581());

        ParticleFactoryRegistry.getInstance().register(ModParticles.EMBER, StrikeParticles.EmberFactory::new);
        ParticleFactoryRegistry.getInstance().register(ModParticles.ASH, StrikeParticles.AshFactory::new);
        ParticleFactoryRegistry.getInstance().register(ModParticles.DEBRIS, StrikeParticles.DebrisFactory::new);

        ClientTickEvents.END_CLIENT_TICK.register(OrbitalStrikeClient::tick);

        // Right-click while holding the Detonator: strike the aimed target.
        net.fabricmc.fabric.api.event.player.UseItemCallback.EVENT.register((player, world, hand) -> {
            net.minecraft.class_1799 stack = player.method_5998(hand);
            if (world.field_9236 && stack.method_31574(fr.orbitalstrike.registry.ModItems.ORBITAL_DETONATOR)) {
                TargetingController.fire(class_310.method_1551());
                return net.minecraft.class_1271.method_22427(stack);
            }
            return net.minecraft.class_1271.method_22430(stack);
        });
        if (SelfTest.ENABLED) SelfTest.register();
        if (CraterSyncTest.ENABLED) CraterSyncTest.register();

        // World-space rendered effects: sky streak, impact column, dust ring.
        WorldRenderEvents.AFTER_TRANSLUCENT.register(WorldFx::render);

        HudRenderCallback.EVENT.register((ctx, tickCounter) -> {
            if (!SelfTest.ENABLED && class_310.method_1551().field_1687 != null) {
                CinematicDirector.warmUpIfNeeded();
            }
            float delta = tickCounter.method_60637(false);
            CinematicDirector.render(ctx, delta);
            FxController.renderHud(ctx, delta);
        });

        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            CinematicDirector.stop();
            WorldCamera.stop();
            FxController.reset();
            ClientState.reset();
        });

        ResourceManagerHelper.get(class_3264.field_14188).registerReloadListener(new SimpleSynchronousResourceReloadListener() {
            @Override
            public class_2960 getFabricId() {
                return class_2960.method_60655("orbital_strike", "post_effects");
            }

            @Override
            public void method_14491(class_3300 manager) {
                PostEffects.invalidate();
                CinematicDirector.invalidate3D();
            }
        });
    }

    private static void tick(class_310 client) {
        if (!client.method_1493()) ClientState.tick();

        while (menuKey.method_1436()) {
            if (client.field_1724 == null) continue;
            if (TargetingController.hasDetonator(client)) {
                client.method_1507(new DetonatorScreen());
            } else {
                client.field_1724.method_7353(class_2561.method_43471("message.orbital_strike.no_item"), true);
            }
        }
        CinematicDirector.tick(client);
        WorldCamera.tick(client);
        TargetingController.tick(client);
        FxController.tick(client);
    }
}
