package fr.orbitalstrike.client.fx;

import com.mojang.blaze3d.systems.RenderSystem;
import fr.orbitalstrike.OrbitalStrike;
import net.minecraft.class_279;
import net.minecraft.class_310;
import org.jetbrains.annotations.Nullable;

/**
 * Full-screen post-processing (custom shader):
 * desaturation + vignette (hush), white flash + chromatic aberration (impact),
 * expanding ring heat distortion (shockwave).
 * Falls back to simple HUD overlays if the shader fails to load.
 */
public final class PostEffects {
    public static float desat, vignette, flash, aberration, heat, heatX = 0.5f, heatY = 0.5f, heatRadius;
    /** Stylized impact (two-tone negative) and post-impact darkened sky, from 0 to 1. */
    public static float stylize, dusk;

    private static @Nullable class_279 processor;
    private static boolean failed = false;
    private static int width = -1, height = -1;
    private static float time = 0f;

    private PostEffects() {}

    public static boolean available() {
        return !failed;
    }

    private static boolean anyActive() {
        return desat > 0.001f || vignette > 0.001f || flash > 0.001f || aberration > 0.001f || heat > 0.001f || stylize > 0.001f || dusk > 0.001f;
    }

    public static void render(float frameDuration) {
        time += frameDuration / 20f;
        if (!anyActive() || failed) return;
        class_310 client = class_310.method_1551();
        if (processor == null) {
            try {
                processor = new class_279(client.method_1531(), client.method_1478(),
                        client.method_1522(), OrbitalStrike.id("shaders/post/strike_fx.json"));
            } catch (Exception e) {
                OrbitalStrike.LOGGER.warn("Post-processing effect unavailable, falling back to HUD layers", e);
                failed = true;
                return;
            }
        }
        var fb = client.method_1522();
        if (fb.field_1482 != width || fb.field_1481 != height) {
            width = fb.field_1482;
            height = fb.field_1481;
            processor.method_1259(width, height);
        }
        processor.method_57799("Desat", desat);
        processor.method_57799("Vignette", vignette);
        processor.method_57799("Flash", flash);
        processor.method_57799("Aberration", aberration);
        processor.method_57799("Heat", heat);
        processor.method_57799("HeatX", heatX);
        processor.method_57799("HeatY", heatY);
        processor.method_57799("HeatRadius", heatRadius);
        processor.method_57799("Time", time);
        processor.method_57799("Stylize", stylize);
        processor.method_57799("Dusk", dusk);

        RenderSystem.disableBlend();
        RenderSystem.disableDepthTest();
        RenderSystem.resetTextureMatrix();
        processor.method_1258(frameDuration);
        client.method_1522().method_1235(true);
    }

    public static void reset() {
        desat = vignette = flash = aberration = heat = heatRadius = stylize = dusk = 0f;
    }

    /** Must be called when client resources are reloaded. */
    public static void invalidate() {
        if (processor != null) processor.close();
        processor = null;
        failed = false;
        width = height = -1;
    }
}
