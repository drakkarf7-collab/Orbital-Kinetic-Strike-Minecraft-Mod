package fr.orbitalstrike.client.cinematic;

import fr.orbitalstrike.client.ClientConfig;
import fr.orbitalstrike.client.ClientState;
import fr.orbitalstrike.client.render.world.WorldFx;
import fr.orbitalstrike.strike.CinematicMode;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_433;
import net.minecraft.class_5498;
import org.jetbrains.annotations.Nullable;

/**
 * World-space cinematic camera for the strike launcher. Three shots:
 * <ul>
 *   <li>LAUNCH, on firing (lock-on and countdown): arcs around the player, zooms rapidly
 *       toward the ground reticle, then climbs vertically along the laser beam;</li>
 *   <li>SKY, upon returning to the ground: low camera near the player looking up at the sky streak
 *       and tracking it down to impact;</li>
 *   <li>AFTERMATH, post-impact: wide shot from the crater rim framing the hexagonal grid,
 *       molten basin, and monumental spire.</li>
 * </ul>
 * Position is overridden by {@code CameraMixin}. View switches to third person during the shots
 * (so the player is rendered and their first-person hand is hidden), then restores the original perspective.
 */
public final class WorldCamera {
    public enum Mode { LAUNCH, SKY, AFTERMATH }

    /** LAUNCH: shot phase splits (0 to 1 progress) and geometry. */
    private static final float ORBIT_END = 0.30f, APPROACH_END = 0.58f;
    private static final double ORBIT_RADIUS_START = 4.6, ORBIT_RADIUS_END = 3.2;
    private static final double ORBIT_HEIGHT_START = 0.30, ORBIT_HEIGHT_END = 0.95;
    private static final double TARGET_VIEW_BACK = 11.5, TARGET_VIEW_LIFT = 2.6;
    private static final double LIFTOFF_HEIGHT = 245.0;
    /** SKY: camera offset relative to the player's feet, and fallback look target before the sky streak appears. */
    private static final double SKY_SIDE = 2.6, SKY_BACK = 1.6, SKY_HEIGHT = 1.85, SKY_FALLBACK_HEIGHT = 75;
    /** AFTERMATH: pullback from the outer crater rim to frame the hex grid, basin, and spire. */
    private static final double AFTER_DIST_START = 1.38, AFTER_DIST_END = 1.66, AFTER_MIN = 30, AFTER_MAX = 124;
    private static final double AFTER_HEIGHT_BASE = 14.0, AFTER_HEIGHT_END_BASE = 20.0;
    private static final double AFTER_HEIGHT_SCALE = 0.18, AFTER_HEIGHT_END_SCALE = 0.28;
    private static final double AFTER_LOOK_UP_SCALE = 0.25, AFTER_LOOK_MIN = 12.0, AFTER_LOOK_MAX = 34.0;
    /** Maximum upward shift in blocks if the camera ends up inside a block. */
    private static final int MAX_UNSTICK = 32;
    /** Safety margin beyond the expected duration, in ticks. */
    private static final int OVERRUN_TICKS = 20;

    private static boolean active = false;
    private static Mode mode = Mode.LAUNCH;
    private static long start;
    private static int duration = 1;
    private static class_243 anchor = class_243.field_1353, target = class_243.field_1353, fixedPos = class_243.field_1353, endPos = class_243.field_1353;
    private static float aftermathRadius = 20f;
    private static @Nullable class_5498 previous;

    private WorldCamera() {}

    public static boolean isActive() {
        return active;
    }

    private static boolean start(Mode m, class_243 targetPos, int ticks) {
        class_310 client = class_310.method_1551();
        ClientConfig cfg = ClientConfig.get();
        if (client.field_1724 == null || !cfg.worldCamera || cfg.mode() == CinematicMode.OFF) return false;
        target = targetPos;
        start = ClientState.ticks();
        duration = Math.max(1, ticks);
        mode = m;
        if (!active) {
            previous = client.field_1690.method_31044();
            client.field_1690.method_31043(class_5498.field_26665);
        }
        active = true;
        return true;
    }

    /** Launch shot: {@code ticks} spans lock-on and countdown. */
    public static void begin(class_243 targetPos, int ticks) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;
        class_243 eye = client.field_1724.method_33571();
        if (start(Mode.LAUNCH, targetPos, ticks)) anchor = eye;
    }

    /** Low upward sky shot: camera placed 28 blocks from the target, tilting up to follow the vertical descent. */
    public static void beginSky(class_243 targetPos, int ticks) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;
        class_243 dir = horizontal(client.field_1724.method_19538().method_1020(targetPos), new class_243(0, 0, 1));
        class_243 flat = targetPos.method_1019(dir.method_1021(28.0));
        double ground = WorldFx.surfaceY(client, flat.field_1352, flat.field_1350, targetPos.field_1351);
        class_243 pos = new class_243(flat.field_1352, Math.max(targetPos.field_1351, ground) + SKY_HEIGHT, flat.field_1350);
        if (start(Mode.SKY, targetPos, ticks)) fixedPos = pos;
    }

    /** Wide crater aftermath shot: frames the hex grid, molten basin, and giant spire from the crater rim. */
    public static void beginAftermath(class_243 targetPos, float radius, int ticks) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) return;
        class_243 dir = horizontal(client.field_1724.method_19538().method_1020(targetPos), new class_243(1, 0, 0));
        double d0 = class_3532.method_15350(radius * AFTER_DIST_START, AFTER_MIN, AFTER_MAX * 0.85);
        double d1 = class_3532.method_15350(radius * AFTER_DIST_END, AFTER_MIN + 8.0, AFTER_MAX);
        class_243 base0 = targetPos.method_1019(dir.method_1021(d0));
        class_243 base1 = targetPos.method_1019(dir.method_1021(d1));
        double ground0 = sampleGround(client, base0.field_1352, base0.field_1350, targetPos.field_1351);
        double ground1 = sampleGround(client, base1.field_1352, base1.field_1350, ground0);
        double h0 = AFTER_HEIGHT_BASE + radius * AFTER_HEIGHT_SCALE;
        double h1 = AFTER_HEIGHT_END_BASE + radius * AFTER_HEIGHT_END_SCALE;
        class_243 from = new class_243(base0.field_1352, ground0 + h0, base0.field_1350);
        class_243 to = new class_243(base1.field_1352, ground1 + h1, base1.field_1350);
        if (start(Mode.AFTERMATH, targetPos, ticks)) {
            aftermathRadius = radius;
            fixedPos = from;
            endPos = to;
        }
    }

    private static double sampleGround(class_310 client, double x, double z, double fallback) {
        return WorldFx.surfaceY(client, x, z, fallback);
    }

    private static class_243 horizontal(class_243 v, class_243 fallback) {
        class_243 flat = new class_243(v.field_1352, 0, v.field_1350);
        return flat.method_1027() < 1e-4 ? fallback : flat.method_1029();
    }

    public static void stop() {
        if (!active) return;
        active = false;
        class_310 client = class_310.method_1551();
        if (previous != null) client.field_1690.method_31043(previous);
        previous = null;
    }

    public static void tick(class_310 client) {
        if (!active) return;
        // Safety net: the shot ends automatically on timeout or when the pause menu opens.
        if (client.field_1724 == null || client.field_1755 instanceof class_433
                || ClientState.ticks() - start > duration + OVERRUN_TICKS) {
            stop();
        }
    }

    private static double smooth(double t) {
        t = class_3532.method_15350(t, 0, 1);
        return t * t * (3 - 2 * t);
    }

    /** Camera position and orientation: {x, y, z, yaw, pitch}, or null if no shot is active. */
    public static double @Nullable [] compute(float tickDelta) {
        if (!active) return null;
        class_310 client = class_310.method_1551();
        if (client.field_1687 == null) return null;
        double k = class_3532.method_15363((ClientState.ticks() - start + tickDelta) / duration, 0, 1);

        class_243 pos, look;
        switch (mode) {
            case SKY -> {
                pos = fixedPos;
                class_243 head = WorldFx.trackedHead(tickDelta);
                look = head != null ? head : target.method_1031(0, SKY_FALLBACK_HEIGHT, 0);
            }
            case AFTERMATH -> {
                pos = fixedPos.method_35590(endPos, smooth(k));
                double lookUp = class_3532.method_15350(12.0 + aftermathRadius * AFTER_LOOK_UP_SCALE, AFTER_LOOK_MIN, AFTER_LOOK_MAX);
                look = target.method_1031(0, lookUp * (0.35 + 0.65 * smooth(k)), 0);
            }
            default -> {
                class_243 toTarget = horizontal(target.method_1020(anchor), new class_243(0, 0, 1));
                double facing = Math.atan2(toTarget.field_1350, toTarget.field_1352);
                class_243 behind = anchor.method_1031(-toTarget.field_1352 * ORBIT_RADIUS_END, ORBIT_HEIGHT_END, -toTarget.field_1350 * ORBIT_RADIUS_END);
                class_243 nearTargetFlat = target.method_1031(-toTarget.field_1352 * TARGET_VIEW_BACK, 0, -toTarget.field_1350 * TARGET_VIEW_BACK);
                double nearGround = sampleGround(client, nearTargetFlat.field_1352, nearTargetFlat.field_1350, target.field_1351);
                class_243 nearTarget = new class_243(nearTargetFlat.field_1352, Math.max(target.field_1351, nearGround) + TARGET_VIEW_LIFT, nearTargetFlat.field_1350);
                if (k < ORBIT_END) {
                    // Arc around the player: from in front to behind their shoulder.
                    double u = smooth(k / ORBIT_END);
                    double angle = facing + 0.35 + (Math.PI - 0.35) * u;
                    double radius = ORBIT_RADIUS_START + (ORBIT_RADIUS_END - ORBIT_RADIUS_START) * u;
                    double height = ORBIT_HEIGHT_START + (ORBIT_HEIGHT_END - ORBIT_HEIGHT_START) * u;
                    pos = anchor.method_1031(Math.cos(angle) * radius, height, Math.sin(angle) * radius);
                    look = anchor.method_1031(0, -0.15, 0).method_35590(target.method_1031(0, 0.8, 0), u * 0.40);
                } else if (k < APPROACH_END) {
                    // Fast dolly toward the hexagonal reticle projected on the target.
                    double u = smooth((k - ORBIT_END) / (APPROACH_END - ORBIT_END));
                    pos = behind.method_35590(nearTarget, u);
                    look = anchor.method_35590(target.method_1031(0, 0.6, 0), 0.40 + 0.60 * u);
                } else {
                    // Accelerated vertical liftoff along the laser beam: tilts skyward at the end to flow seamlessly into ASCENT.
                    double u = (k - APPROACH_END) / (1 - APPROACH_END);
                    double climb = LIFTOFF_HEIGHT * Math.pow(u, 2.25);
                    double backDist = TARGET_VIEW_BACK + 9.0 * u * u;
                    double skyTilt = Math.max(0.0, (u - 0.68) / 0.32);
                    class_243 flatLift = target.method_1031(-toTarget.field_1352 * backDist, 0, -toTarget.field_1350 * backDist);
                    pos = new class_243(flatLift.field_1352, nearTarget.field_1351 + climb, flatLift.field_1350);
                    look = target.method_1031(0, 0.6 + 12.0 * u * u + 125.0 * skyTilt * skyTilt, 0);
                }
            }
        }

        // Safety floor: never clip below the surface or remain stuck inside a block.
        double minGround = sampleGround(client, pos.field_1352, pos.field_1350, target.field_1351) + 2.0;
        if (pos.field_1351 < minGround) pos = new class_243(pos.field_1352, minGround, pos.field_1350);
        class_2338.class_2339 probe = new class_2338.class_2339();
        for (int i = 0; i < MAX_UNSTICK; i++) {
            probe.method_10103(class_3532.method_15357(pos.field_1352), class_3532.method_15357(pos.field_1351), class_3532.method_15357(pos.field_1350));
            if (client.field_1687.method_8320(probe).method_26220(client.field_1687, probe).method_1110()) break;
            pos = pos.method_1031(0, 1, 0);
        }

        class_243 d = look.method_1020(pos);
        double horizontalLen = Math.sqrt(d.field_1352 * d.field_1352 + d.field_1350 * d.field_1350);
        double yaw = Math.toDegrees(Math.atan2(-d.field_1352, d.field_1350));
        double pitch = -Math.toDegrees(Math.atan2(d.field_1351, horizontalLen));
        return new double[]{pos.field_1352, pos.field_1351, pos.field_1350, yaw, pitch};
    }
}
