package fr.orbitalstrike.client.particle;

import net.minecraft.class_2400;
import net.minecraft.class_3999;
import net.minecraft.class_4002;
import net.minecraft.class_4003;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;

/**
 * The three mod particles:
 * ember (slowly rises, emissive), ash (slowly falls), debris (ballistic).
 */
public final class StrikeParticles {
    private StrikeParticles() {}

    public static final class Ember extends class_4003 {
        Ember(class_638 world, double x, double y, double z, double vx, double vy, double vz, class_4002 sprites) {
            super(world, x, y, z, vx, vy, vz);
            this.field_3852 = vx;
            this.field_3869 = vy;
            this.field_3850 = vz;
            this.field_3844 = -0.02f;
            this.field_28786 = 0.94f;
            this.field_3847 = 30 + field_3840.method_43048(40);
            this.field_17867 = 0.08f + field_3840.method_43057() * 0.08f;
            this.method_3084(0.28f + field_3840.method_43057() * 0.35f, 0.72f + field_3840.method_43057() * 0.25f, 1.0f);
            this.method_18140(sprites);
        }

        @Override
        public class_3999 method_18122() {
            return class_3999.field_17829;
        }

        @Override
        public int method_3068(float tint) {
            return 0xF000F0;
        }

        @Override
        public void method_3070() {
            super.method_3070();
            this.field_3841 = Math.max(0f, 1f - field_3866 / (float) field_3847);
        }
    }

    public static final class Ash extends class_4003 {
        Ash(class_638 world, double x, double y, double z, double vx, double vy, double vz, class_4002 sprites) {
            super(world, x, y, z, vx, vy, vz);
            this.field_3852 = vx;
            this.field_3869 = vy;
            this.field_3850 = vz;
            this.field_3844 = 0.015f;
            this.field_28786 = 0.96f;
            this.field_3847 = 80 + field_3840.method_43048(80);
            this.field_17867 = 0.15f + field_3840.method_43057() * 0.2f;
            float g = 0.2f + field_3840.method_43057() * 0.2f;
            this.method_3084(g, g, g);
            this.method_18140(sprites);
        }

        @Override
        public class_3999 method_18122() {
            return class_3999.field_17829;
        }

        @Override
        public void method_3070() {
            super.method_3070();
            this.field_3841 = Math.min(1f, (field_3847 - field_3866) / 30f);
        }
    }

    public static final class Debris extends class_4003 {
        Debris(class_638 world, double x, double y, double z, double vx, double vy, double vz, class_4002 sprites) {
            super(world, x, y, z, vx, vy, vz);
            this.field_3852 = vx;
            this.field_3869 = vy;
            this.field_3850 = vz;
            this.field_3844 = 0.9f;
            this.field_28786 = 0.98f;
            this.field_3862 = true;
            this.field_3847 = 40 + field_3840.method_43048(40);
            this.field_17867 = 0.12f + field_3840.method_43057() * 0.15f;
            float g = 0.3f + field_3840.method_43057() * 0.25f;
            this.method_3084(g, g * 0.95f, g * 0.9f);
            this.method_18140(sprites);
        }

        @Override
        public class_3999 method_18122() {
            return class_3999.field_17828;
        }
    }

    public record EmberFactory(class_4002 sprites) implements class_707<class_2400> {
        @Override
        public class_703 createParticle(class_2400 type, class_638 world, double x, double y, double z,
                                       double vx, double vy, double vz) {
            return new Ember(world, x, y, z, vx, vy, vz, sprites);
        }
    }

    public record AshFactory(class_4002 sprites) implements class_707<class_2400> {
        @Override
        public class_703 createParticle(class_2400 type, class_638 world, double x, double y, double z,
                                       double vx, double vy, double vz) {
            return new Ash(world, x, y, z, vx, vy, vz, sprites);
        }
    }

    public record DebrisFactory(class_4002 sprites) implements class_707<class_2400> {
        @Override
        public class_703 createParticle(class_2400 type, class_638 world, double x, double y, double z,
                                       double vx, double vy, double vz) {
            return new Debris(world, x, y, z, vx, vy, vz, sprites);
        }
    }
}
