package fr.orbitalstrike.client.gui;

import fr.orbitalstrike.client.ClientConfig;
import fr.orbitalstrike.client.ClientState;
import fr.orbitalstrike.client.targeting.TargetingController;
import fr.orbitalstrike.crater.CraterProfile;
import fr.orbitalstrike.registry.ModItems;
import fr.orbitalstrike.strike.CinematicMode;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.class_1109;
import net.minecraft.class_156;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3417;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import net.minecraft.class_5481;

/**
 * Card-based Detonator menu:
 * <ul>
 *   <li>on the left, the item card (preview, description, status, cooldown) and toggles
 *       (cutscene, captions, world camera);</li>
 *   <li>on the right, the skill card with its keybinding and integrated sliders (power, speed).</li>
 * </ul>
 * Styling: translucent dark chamfered panels, sapphire-blue borders, animated open transition.
 * All widgets are custom-drawn here (no standard Minecraft buttons).
 */
public class DetonatorScreen extends class_437 {
    private static final class_2960 ICON = class_2960.method_60655("orbital_strike", "textures/gui/skill/kinetic_strike.png");
    private static final int AMBER = 0xFFE8A438, PANEL = 0xD20E1016, PANEL_HOVER = 0xE0181B24, INSET = 0xFF07080C;
    private static final int TEXT = 0xFFE8E8EC, MUTED = 0xFF9A9CA6, GOOD = 0xFF5FD38A, BAD = 0xFFFF5A47, CYAN = 0xFF5FE6FF;
    private static final int LEFT_W = 150, RIGHT_W = 250, GAP = 10, ROW_H = 20, ROW_GAP = 3, CUT = 3;
    private static final int ITEM_CARD_H = 142, SKILL_CARD_H = 44;
    /** Width reserved for the value label displayed to the right of a slider. */
    private static final int SLIDER_VALUE_W = 92;
    private static final float OPEN_MS = 170f;
    private static final float SPEED_MIN = 0.5f, SPEED_MAX = 2.0f, SPEED_STEP = 0.5f;

    /** Active slider being dragged: 0 = none, 1 = power, 2 = speed. */
    private int dragging = 0;
    private boolean capturing = false;
    private long openedAt;
    private int left, top, rightX;

    public DetonatorScreen() {
        super(class_2561.method_43471("gui.orbital_strike.menu.title"));
    }

    @Override
    protected void method_25426() {
        left = (field_22789 - LEFT_W - GAP - RIGHT_W) / 2;
        rightX = left + LEFT_W + GAP;
        top = Math.max(34, field_22790 / 2 - 112);
        if (openedAt == 0) openedAt = class_156.method_658();
    }

    // ------------------------------------------------------------------ layout geometry

    private int toggleY(int index) {
        return top + ITEM_CARD_H + 6 + index * (ROW_H + ROW_GAP);
    }

    private int sliderY(int index) {
        return top + SKILL_CARD_H + ROW_GAP + index * (ROW_H + ROW_GAP);
    }

    private int sliderTrackX() {
        return rightX + 76;
    }

    private int sliderTrackW() {
        return RIGHT_W - 76 - SLIDER_VALUE_W;
    }

    private static boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    // ------------------------------------------------------------------ rendering

    /** Dark panel with chamfered corners. */
    private static void panel(class_332 ctx, int x, int y, int w, int h, int color) {
        ctx.method_25294(x + CUT, y, x + w - CUT, y + h, color);
        ctx.method_25294(x, y + CUT, x + CUT, y + h - CUT, color);
        ctx.method_25294(x + w - CUT, y + CUT, x + w, y + h - CUT, color);
        for (int i = 1; i < CUT; i++) {
            ctx.method_25294(x + i, y + CUT - i, x + CUT, y + CUT, color);
            ctx.method_25294(x + w - CUT, y + CUT - i, x + w - i, y + CUT, color);
            ctx.method_25294(x + i, y + h - CUT, x + CUT, y + h - CUT + i, color);
            ctx.method_25294(x + w - CUT, y + h - CUT, x + w - i, y + h - CUT + i, color);
        }
    }

    private static String spaced(String s) {
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < s.length(); i++) out.append(s.charAt(i)).append(i < s.length() - 1 ? " " : "");
        return out.toString();
    }

    @Override
    public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
        super.method_25394(ctx, mouseX, mouseY, delta);
        float open = Math.min(1f, (class_156.method_658() - openedAt) / OPEN_MS);
        float ease = 1f - (1f - open) * (1f - open);
        ClientConfig cfg = ClientConfig.get();
        class_310 mc = class_310.method_1551();

        ctx.method_51448().method_22903();
        // Opening transition: cards slide upward by a few pixels.
        ctx.method_51448().method_46416(0, (1f - ease) * 10f, 0);

        // Title.
        String title = spaced(class_2561.method_43471("gui.orbital_strike.menu.banner").getString());
        int titleW = field_22793.method_1727(title);
        ctx.method_51433(field_22793, title, (field_22789 - titleW) / 2, top - 22, TEXT, false);
        ctx.method_25294((field_22789 - titleW) / 2, top - 11, (field_22789 + titleW) / 2, top - 10, AMBER);

        drawItemCard(ctx, mc);
        drawToggles(ctx, cfg, mouseX, mouseY);
        drawSkillCard(ctx, cfg, mouseX, mouseY);
        drawSliders(ctx, cfg, mouseX, mouseY);

        int hintY = sliderY(2) + 4;
        for (class_5481 line : field_22793.method_1728(class_2561.method_43471("gui.orbital_strike.menu.hint"), RIGHT_W - 8)) {
            ctx.method_51430(field_22793, line, rightX + 4, hintY, MUTED, false);
            hintY += 10;
        }
        List<String> clashes = clashes(cfg.skillKey);
        if (!capturing && !clashes.isEmpty()) {
            ctx.method_51439(field_22793, class_2561.method_43469("gui.orbital_strike.clash", String.join(", ", clashes)),
                    rightX + 4, hintY + 2, 0xFFFFD36A, false);
        }
        ctx.method_51448().method_22909();
    }

    private void drawItemCard(class_332 ctx, class_310 mc) {
        panel(ctx, left, top, LEFT_W, ITEM_CARD_H, PANEL);
        ctx.method_25294(left + CUT, top, left + LEFT_W - CUT, top + 2, AMBER);
        String name = spaced(class_2561.method_43471("gui.orbital_strike.menu.item").getString());
        ctx.method_51433(field_22793, name, left + (LEFT_W - field_22793.method_1727(name)) / 2, top + 9, TEXT, false);

        // Enlarged item preview inside a dark inset frame.
        int cx = left + LEFT_W / 2, cy = top + 44;
        panel(ctx, cx - 22, cy - 22, 44, 44, INSET);
        ctx.method_51448().method_22903();
        ctx.method_51448().method_46416(cx - 16, cy - 16, 0);
        ctx.method_51448().method_22905(2f, 2f, 1f);
        ctx.method_51427(new class_1799(ModItems.ORBITAL_DETONATOR), 0, 0);
        ctx.method_51448().method_22909();

        int y = top + 72;
        for (class_5481 line : field_22793.method_1728(class_2561.method_43471("item.orbital_strike.orbital_detonator.lore"), LEFT_W - 16)) {
            ctx.method_51430(field_22793, line, left + (LEFT_W - field_22793.method_30880(line)) / 2, y, MUTED, false);
            y += 10;
        }

        boolean carried = TargetingController.hasDetonator(mc);
        class_2561 state = class_2561.method_43471(carried ? "gui.orbital_strike.carried" : "gui.orbital_strike.missing");
        int pillW = field_22793.method_27525(state) + 14;
        panel(ctx, cx - pillW / 2, top + ITEM_CARD_H - 38, pillW, 13, carried ? 0x5028A060 : 0x50C03020);
        ctx.method_51439(field_22793, state, cx - field_22793.method_27525(state) / 2, top + ITEM_CARD_H - 35, carried ? GOOD : BAD, false);

        // Cooldown: bar and label.
        int remaining = ClientState.cooldownRemainingTicks();
        int barX = left + 12, barW = LEFT_W - 24, barY = top + ITEM_CARD_H - 9;
        float frac = remaining > 0 ? 1f - remaining / (float) Math.max(1, ClientState.cooldownTotalTicks()) : 1f;
        ctx.method_25294(barX, barY, barX + barW, barY + 2, INSET);
        ctx.method_25294(barX, barY, barX + (int) (barW * frac), barY + 2, remaining > 0 ? AMBER : GOOD);
        class_2561 ready = remaining > 0 ? class_2561.method_43469("gui.orbital_strike.recharging", (remaining + 19) / 20)
                : class_2561.method_43471("gui.orbital_strike.ready");
        ctx.method_51439(field_22793, ready, cx - field_22793.method_27525(ready) / 2, barY - 10, remaining > 0 ? MUTED : GOOD, false);
    }

    private void drawToggles(class_332 ctx, ClientConfig cfg, int mouseX, int mouseY) {
        CinematicMode mode = cfg.mode();
        drawToggleRow(ctx, 0, class_2561.method_43471("gui.orbital_strike.row.cinematic"),
                class_2561.method_43471("gui.orbital_strike.cinematic." + mode.name().toLowerCase(Locale.ROOT)).getString(),
                mode != CinematicMode.OFF, mouseX, mouseY);
        drawToggleRow(ctx, 1, class_2561.method_43471("gui.orbital_strike.row.camera"), null, cfg.worldCamera, mouseX, mouseY);
        drawToggleRow(ctx, 2, class_2561.method_43471("gui.orbital_strike.row.captions"), null, cfg.directorCaptions, mouseX, mouseY);
    }

    private void drawToggleRow(class_332 ctx, int index, class_2561 label, String value, boolean on, int mouseX, int mouseY) {
        int y = toggleY(index);
        boolean hover = inside(mouseX, mouseY, left, y, LEFT_W, ROW_H);
        panel(ctx, left, y, LEFT_W, ROW_H, hover ? PANEL_HOVER : PANEL);
        ctx.method_51439(field_22793, label, left + 8, y + 6, TEXT, false);
        // Toggle switch: track and thumb, amber when enabled.
        int sx = left + LEFT_W - 30, sy = y + 5;
        panel(ctx, sx, sy, 22, 10, on ? 0xFF4D320C : INSET);
        ctx.method_25294(on ? sx + 13 : sx + 2, sy + 2, on ? sx + 20 : sx + 9, sy + 8, on ? AMBER : MUTED);
        if (value != null) ctx.method_51433(field_22793, value, sx - 6 - field_22793.method_1727(value), y + 6, on ? AMBER : MUTED, false);
    }

    private void drawSkillCard(class_332 ctx, ClientConfig cfg, int mouseX, int mouseY) {
        boolean hover = inside(mouseX, mouseY, rightX, top, RIGHT_W, SKILL_CARD_H);
        panel(ctx, rightX, top, RIGHT_W, SKILL_CARD_H, hover ? PANEL_HOVER : PANEL);
        // Left selection accent strip.
        ctx.method_25294(rightX, top + CUT, rightX + 2, top + SKILL_CARD_H - CUT, cfg.skillSelected ? AMBER : MUTED);
        panel(ctx, rightX + 8, top + 6, 32, 32, INSET);
        ctx.method_25290(ICON, rightX + 8, top + 6, 0, 0, 32, 32, 32, 32);
        ctx.method_51439(field_22793, class_2561.method_43471("skill.orbital_strike.kinetic_strike"), rightX + 48, top + 10, TEXT, false);
        ctx.method_51439(field_22793, class_2561.method_43471("gui.orbital_strike.menu.subtitle"), rightX + 48, top + 23, MUTED, false);

        // Keybind badge: click to rebind.
        String key = capturing ? "..." : keyName(cfg.skillKey).getString();
        int badgeW = Math.max(18, field_22793.method_1727(key) + 10);
        int bx = rightX + RIGHT_W - badgeW - 8, by = top + 14;
        panel(ctx, bx, by, badgeW, 16, capturing ? 0xFF14404A : INSET);
        ctx.method_51433(field_22793, key, bx + (badgeW - field_22793.method_1727(key)) / 2, by + 4, capturing ? CYAN : TEXT, false);
    }

    private void drawSliders(class_332 ctx, ClientConfig cfg, int mouseX, int mouseY) {
        int maxPower = Math.max(1, ClientState.maxPower());
        int power = Math.min(cfg.power, maxPower);
        float powerFrac = maxPower <= 1 ? 1f : (power - 1) / (float) (maxPower - 1);
        drawSlider(ctx, 0, class_2561.method_43471("gui.orbital_strike.row.power"), powerFrac,
                class_2561.method_43469("gui.orbital_strike.value.power", power, CraterProfile.basinRadius(power)).getString(),
                mouseX, mouseY);
        float speedFrac = (cfg.speed - SPEED_MIN) / (SPEED_MAX - SPEED_MIN);
        drawSlider(ctx, 1, class_2561.method_43471("gui.orbital_strike.row.speed"), speedFrac,
                String.format(Locale.ROOT, "x%.1f", cfg.speed), mouseX, mouseY);
    }

    private void drawSlider(class_332 ctx, int index, class_2561 label, float fraction, String value, int mouseX, int mouseY) {
        int y = sliderY(index);
        boolean hover = inside(mouseX, mouseY, rightX, y, RIGHT_W, ROW_H) || dragging == index + 1;
        panel(ctx, rightX + 10, y, RIGHT_W - 10, ROW_H, hover ? PANEL_HOVER : PANEL);
        ctx.method_51439(field_22793, label, rightX + 18, y + 6, MUTED, false);
        int tx = sliderTrackX(), tw = sliderTrackW(), ty = y + 9;
        ctx.method_25294(tx, ty, tx + tw, ty + 2, INSET);
        int knob = tx + Math.round(tw * Math.max(0f, Math.min(1f, fraction)));
        ctx.method_25294(tx, ty, knob, ty + 2, AMBER);
        panel(ctx, knob - 4, ty - 4, 8, 10, hover ? 0xFFFFFFFF : TEXT);
        ctx.method_51433(field_22793, value, rightX + RIGHT_W - 8 - field_22793.method_1727(value), y + 6, TEXT, false);
    }

    // ------------------------------------------------------------------ input handling

    private void click() {
        class_310.method_1551().method_1483().method_4873(class_1109.method_47978(class_3417.field_15015, 1f));
    }

    private void dragTo(double mouseX) {
        float f = (float) Math.max(0, Math.min(1, (mouseX - sliderTrackX()) / sliderTrackW()));
        ClientConfig cfg = ClientConfig.get();
        if (dragging == 1) {
            int maxPower = Math.max(1, ClientState.maxPower());
            cfg.power = 1 + Math.round(f * (maxPower - 1));
        } else if (dragging == 2) {
            float raw = SPEED_MIN + f * (SPEED_MAX - SPEED_MIN);
            cfg.speed = Math.round(raw / SPEED_STEP) * SPEED_STEP;
        }
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        ClientConfig cfg = ClientConfig.get();
        if (capturing) {
            capturing = false;
            return true;
        }
        for (int i = 0; i < 2; i++) {
            if (inside(mouseX, mouseY, rightX, sliderY(i), RIGHT_W, ROW_H)) {
                dragging = i + 1;
                dragTo(mouseX);
                click();
                return true;
            }
        }
        if (inside(mouseX, mouseY, rightX, top, RIGHT_W, SKILL_CARD_H)) {
            // Clicking the key badge (or right-clicking the card) rebinds the key; otherwise toggle selection.
            boolean onBadge = mouseX >= rightX + RIGHT_W - 60;
            if (onBadge || button == GLFW.GLFW_MOUSE_BUTTON_RIGHT) capturing = true;
            else cfg.skillSelected = !cfg.skillSelected;
            click();
            return true;
        }
        for (int i = 0; i < 3; i++) {
            if (!inside(mouseX, mouseY, left, toggleY(i), LEFT_W, ROW_H)) continue;
            switch (i) {
                case 0 -> cfg.cinematicMode = cfg.mode().next().name();
                case 1 -> cfg.worldCamera = !cfg.worldCamera;
                default -> cfg.directorCaptions = !cfg.directorCaptions;
            }
            click();
            ClientConfig.save();
            return true;
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (dragging != 0) {
            dragTo(mouseX);
            return true;
        }
        return super.method_25403(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        if (dragging != 0) {
            dragging = 0;
            ClientConfig.save();
            return true;
        }
        return super.method_25406(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (capturing) {
            capturing = false;
            if (keyCode != GLFW.GLFW_KEY_ESCAPE) {
                ClientConfig.get().skillKey = keyCode;
                ClientConfig.get().skillSelected = true;
                ClientConfig.save();
            }
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    private static class_2561 keyName(int code) {
        return class_3675.class_307.field_1668.method_1447(code).method_27445();
    }

    /** Minecraft keybindings already bound to the same key. */
    private List<String> clashes(int code) {
        List<String> out = new ArrayList<>();
        if (field_22787 == null) return out;
        class_3675.class_306 key = class_3675.class_307.field_1668.method_1447(code);
        for (class_304 kb : field_22787.field_1690.field_1839) {
            if (kb.method_1428().equals(key.method_1441())) {
                out.add(class_2561.method_43471(kb.method_1431()).getString());
            }
        }
        return out;
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    public void method_25419() {
        ClientConfig.save();
        super.method_25419();
    }
}
