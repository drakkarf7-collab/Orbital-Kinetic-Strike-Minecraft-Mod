package fr.orbitalstrike.client.targeting;

import fr.orbitalstrike.client.ClientConfig;
import fr.orbitalstrike.client.ClientState;
import fr.orbitalstrike.client.fx.FxController;
import fr.orbitalstrike.client.render.world.WorldFx;
import fr.orbitalstrike.crater.CraterProfile;
import fr.orbitalstrike.network.Payloads;
import fr.orbitalstrike.registry.ModItems;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_3965;
import org.jetbrains.annotations.Nullable;

/**
 * Aiming and firing controller.
 * <ul>
 *   <li>Holding the Detonator: projects the future crater marker onto the aimed ground point,
 *       and a <b>right-click</b> launches the strike.</li>
 *   <li>Skill keybinding: hold to aim, release to strike, even if the Detonator is only in the inventory.</li>
 * </ul>
 */
public final class TargetingController {
    /** Minimum delay between two strike requests (anti-double-click), in ticks. */
    private static final int FIRE_DEBOUNCE_TICKS = 10;

    private static boolean aiming = false;
    private static boolean keyAiming = false;
    private static @Nullable class_2338 target;
    private static long lastFire = -FIRE_DEBOUNCE_TICKS;

    private TargetingController() {}

    public static boolean isAiming() {
        return aiming;
    }

    public static boolean hasDetonator(class_310 client) {
        return client.field_1724 != null && client.field_1724.method_31548().method_7379(ModItems.ORBITAL_DETONATOR.method_7854());
    }

    public static boolean holdsDetonator(class_310 client) {
        return client.field_1724 != null && (client.field_1724.method_6047().method_31574(ModItems.ORBITAL_DETONATOR)
                || client.field_1724.method_6079().method_31574(ModItems.ORBITAL_DETONATOR));
    }

    public static void tick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) {
            aiming = keyAiming = false;
            return;
        }
        ClientConfig cfg = ClientConfig.get();
        boolean free = client.field_1755 == null;
        boolean key = free && cfg.skillSelected && cfg.skillKey != class_3675.field_16237.method_1444()
                && class_3675.method_15987(client.method_22683().method_4490(), cfg.skillKey);
        boolean held = free && holdsDetonator(client);

        if (keyAiming && !key) {
            // Keybinding released: strike the last aimed target.
            keyAiming = false;
            fire(client);
        }
        if (key && !hasDetonator(client)) {
            if (!keyAiming) client.field_1724.method_7353(class_2561.method_43471("message.orbital_strike.no_item"), true);
            keyAiming = true;
            aiming = false;
            target = null;
            return;
        }
        // While own strike is active, stop aiming: the target is already locked.
        if (!(key || held) || FxController.hasOwnStrike()) {
            aiming = false;
            if (!key) target = null;
            return;
        }

        aiming = true;
        keyAiming = key;
        target = raycast(client);
        int remaining = ClientState.cooldownRemainingTicks();
        if (target != null) {
            int power = Math.min(cfg.power, ClientState.maxPower());
            WorldFx.aimMarker(class_243.method_24955(target).method_1031(0, 1, 0), CraterProfile.basinRadius(power), remaining == 0);
        }
        if (remaining > 0) {
            client.field_1724.method_7353(class_2561.method_43469("message.orbital_strike.cooldown", (remaining + 19) / 20), true);
        } else if (target != null) {
            client.field_1724.method_7353(class_2561.method_43469(key ? "hud.orbital_strike.aiming_key" : "hud.orbital_strike.aiming",
                    target.method_23854()), true);
        } else {
            client.field_1724.method_7353(class_2561.method_43471("message.orbital_strike.no_target"), true);
        }
    }

    /** Requests a strike on the aimed target. Returns true if the request was sent. */
    public static boolean fire(class_310 client) {
        if (client.field_1724 == null || !hasDetonator(client)) return false;
        long now = ClientState.ticks();
        if (now - lastFire < FIRE_DEBOUNCE_TICKS || FxController.hasOwnStrike()) return false;
        class_2338 aim = target != null ? target : raycast(client);
        if (aim == null) {
            client.field_1724.method_7353(class_2561.method_43471("message.orbital_strike.no_target"), true);
            return false;
        }
        int remaining = ClientState.cooldownRemainingTicks();
        if (remaining > 0) {
            client.field_1724.method_7353(class_2561.method_43469("message.orbital_strike.cooldown", (remaining + 19) / 20), true);
            return false;
        }
        ClientConfig cfg = ClientConfig.get();
        int power = Math.min(cfg.power, ClientState.maxPower());
        ClientPlayNetworking.send(new Payloads.RequestStrike(aim, power, cfg.speed, cfg.mode().ordinal()));
        lastFire = now;
        target = null;
        return true;
    }

    private static @Nullable class_2338 raycast(class_310 client) {
        class_239 hit = client.field_1724.method_5745(ClientState.maxRange(), 1.0f, false);
        if (hit.method_17783() != class_239.class_240.field_1332) return null;
        return ((class_3965) hit).method_17777();
    }
}
