package fr.orbitalstrike.client.debug;

import fr.orbitalstrike.OrbitalStrike;
import fr.orbitalstrike.skill.SkillContext;
import fr.orbitalstrike.strike.CinematicMode;
import fr.orbitalstrike.strike.StrikeManager;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.class_1011;
import net.minecraft.class_1132;
import net.minecraft.class_1267;
import net.minecraft.class_1923;
import net.minecraft.class_1928;
import net.minecraft.class_1934;
import net.minecraft.class_1940;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2902;
import net.minecraft.class_310;
import net.minecraft.class_318;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_442;
import net.minecraft.class_5285;
import net.minecraft.class_5317;
import net.minecraft.class_638;
import net.minecraft.class_7712;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Comparator;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Live world integration test (integrated server + client + Sodium) enabled by
 * {@code -Dorbital_strike.worldtest=true} via {@code ./gradlew runWorldtest}.
 * Places the player ~198 blocks away (> 128-block server tick radius) from impact,
 * triggers a strike, then verifies block-by-block that client and server match.
 */
public final class CraterSyncTest {
    public static final boolean ENABLED = Boolean.getBoolean("orbital_strike.worldtest");
    private static final String WORLD_NAME = "_crater_worldtest";

    private enum State { IDLE, STARTED_WORLD, WAITING_CHUNKS, STRIKING, SETTLING, PHOTO, DONE }

    private static State state = State.IDLE;
    private static int waitTicks = 0;
    private static int photoFrames = 0;
    private static int groundY = 64;
    private static int failedMismatches = 0;

    private CraterSyncTest() {}

    public static void register() {
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (state == State.IDLE && screen instanceof class_442) {
                startWorld(client);
            }
        });
        HudRenderCallback.EVENT.register((ctx, tickCounter) -> onFrame(class_310.method_1551()));
        ClientTickEvents.END_CLIENT_TICK.register(CraterSyncTest::onTick);
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
            deleteWorldSave(client.field_1697.toPath().resolve("saves").resolve(WORLD_NAME));
            if (failedMismatches > 0) {
                OrbitalStrike.LOGGER.error("[worldtest] FAILED: {} desynced blocks", failedMismatches);
                System.exit(2);
            }
        });
    }

    private static void startWorld(class_310 client) {
        state = State.STARTED_WORLD;
        deleteWorldSave(client.field_1697.toPath().resolve("saves").resolve(WORLD_NAME));
        client.field_1690.field_1837 = false;
        client.field_1690.method_42503().method_41748(16);
        client.field_1690.method_42510().method_41748(10);

        class_1940 info = new class_1940(WORLD_NAME, class_1934.field_9220, false,
                class_1267.field_5801, true, new class_1928(), class_7712.field_40260);
        class_5285 genOpts = new class_5285(42L, false, false);
        client.method_41735().method_41895(
                WORLD_NAME, info, genOpts, class_5317::method_41598, client.field_1755);
    }

    private static void onTick(class_310 client) {
        if (state == State.IDLE || state == State.DONE || state == State.PHOTO) return;
        class_1132 server = client.method_1576();
        class_638 cw = client.field_1687;
        if (server == null || cw == null || client.field_1724 == null) return;

        if (state == State.STARTED_WORLD) {
            state = State.WAITING_CHUNKS;
            waitTicks = 0;
            server.execute(() -> {
                class_3222 sp = server.method_3760().method_14571().getFirst();
                class_3218 sw = sp.method_51469();
                int y = sw.method_8624(class_2902.class_2903.field_13202, 140, 140);
                sp.method_5859(140.5, y + 30.0, 140.5);
                groundY = sw.method_8624(class_2902.class_2903.field_13202, 0, 0);
            });
            return;
        }

        if (state == State.WAITING_CHUNKS) {
            waitTicks++;
            boolean centerLoaded = cw.method_2935().method_12123(0, 0)
                    && cw.method_2935().method_12123(-5, 0)
                    && cw.method_2935().method_12123(5, 0)
                    && cw.method_2935().method_12123(0, -5)
                    && cw.method_2935().method_12123(0, 5);
            if (waitTicks >= 80 && centerLoaded) {
                state = State.STRIKING;
                waitTicks = 0;
                server.execute(() -> {
                    class_3222 sp = server.method_3760().method_14571().getFirst();
                    class_3218 sw = sp.method_51469();
                    groundY = Math.max(60, sw.method_8624(class_2902.class_2903.field_13202, 0, 0));
                    StrikeManager.start(new SkillContext(sp, sw, new class_2338(0, groundY, 0),
                            4, 8.0f, CinematicMode.OFF));
                });
            }
            return;
        }

        if (state == State.STRIKING) {
            waitTicks++;
            AtomicBoolean active = new AtomicBoolean(true);
            server.method_20493(() -> active.set(StrikeManager.activeCount() > 0)).join();
            if (waitTicks >= 80 && !active.get()) {
                state = State.SETTLING;
                waitTicks = 0;
            }
            return;
        }

        if (state == State.SETTLING) {
            waitTicks++;
            if (waitTicks == 60) {
                verifyClientMatchesServer(client, server, cw);
                // Position camera on an already-loaded side to inspect the spire and crater
                server.execute(() -> {
                    class_3222 sp = server.method_3760().method_14571().getFirst();
                    sp.field_13987.method_14363(84.0, groundY + 42.0, 84.0, 135.0f, 14.0f);
                });
                state = State.PHOTO;
                photoFrames = 0;
            }
        }
    }

    private static void verifyClientMatchesServer(class_310 client, class_1132 server, class_638 cw) {
        record Sample(class_2338 pos, class_2680 serverState) {}
        var samples = new java.util.ArrayList<Sample>();
        var verifiedChunks = new java.util.HashSet<class_1923>();

        server.method_20493(() -> {
            class_3218 sw = server.method_30002();
            int bottomY = Math.max(sw.method_31607() + 1, groundY - 48);
            int topY = Math.min(sw.method_31600() - 1, groundY + 24);
            for (int cx = -12; cx <= 12; cx++) {
                for (int cz = -12; cz <= 12; cz++) {
                    if (!sw.method_8393(cx, cz)) continue;
                    class_1923 cpos = new class_1923(cx, cz);
                    verifiedChunks.add(cpos);
                    int bx = cpos.method_8326();
                    int bz = cpos.method_8328();
                    for (int lx = 0; lx < 16; lx += 4) {
                        for (int lz = 0; lz < 16; lz += 4) {
                            for (int y = bottomY; y <= topY; y += 4) {
                                class_2338 p = new class_2338(bx + lx, y, bz + lz);
                                samples.add(new Sample(p, sw.method_8320(p)));
                            }
                        }
                    }
                }
            }
        }).join();

        int clientLoadedChunks = 0;
        int checkedBlocks = 0;
        int mismatchedBlocks = 0;
        var badChunks = new java.util.HashSet<class_1923>();
        for (class_1923 cp : verifiedChunks) {
            if (cw.method_2935().method_12123(cp.field_9181, cp.field_9180)) clientLoadedChunks++;
        }
        for (Sample s : samples) {
            class_1923 cp = new class_1923(s.pos());
            if (!cw.method_2935().method_12123(cp.field_9181, cp.field_9180)) continue;
            checkedBlocks++;
            class_2680 cState = cw.method_8320(s.pos());
            if (!s.serverState().equals(cState)) {
                mismatchedBlocks++;
                badChunks.add(cp);
                if (mismatchedBlocks <= 8) {
                    OrbitalStrike.LOGGER.error(
                            "[worldtest] Desync at {} ({}): server={}, client={}",
                            s.pos().method_23854(), cp, s.serverState().method_26204(), cState.method_26204());
                }
            }
        }

        failedMismatches = mismatchedBlocks;
        OrbitalStrike.LOGGER.info(
                "[worldtest] Verified: {} client chunks, {} blocks, {} desynced blocks ({} desynced chunks)",
                clientLoadedChunks, checkedBlocks, mismatchedBlocks, badChunks.size());
        if (clientLoadedChunks < 100) {
            failedMismatches = Math.max(failedMismatches, 1);
            OrbitalStrike.LOGGER.error("[worldtest] Too few verified chunks: {}", clientLoadedChunks);
        }
    }

    private static void onFrame(class_310 client) {
        if (state != State.PHOTO) return;
        if (client.field_1687 == null || client.field_1755 != null) return;
        photoFrames++;
        boolean ready = client.field_1769.method_3281() && photoFrames >= 180;
        if (!ready && photoFrames < 320) return;

        OrbitalStrike.LOGGER.info("[worldtest] photoFrames={}, terrainComplete={}",
                photoFrames, client.field_1769.method_3281());
        state = State.DONE;
        try {
            Path dir = client.field_1697.toPath().resolve("selftest");
            Files.createDirectories(dir);
            try (class_1011 img = class_318.method_1663(client.method_1522())) {
                img.method_4314(dir.resolve("live_crater_sync.png"));
            }
            OrbitalStrike.LOGGER.info("[worldtest] captured live_crater_sync.png");
        } catch (Exception e) {
            OrbitalStrike.LOGGER.error("[worldtest] screenshot failed", e);
        }

        OrbitalStrike.LOGGER.info(failedMismatches == 0
                ? "[worldtest] SUCCESS: 0 desync"
                : "[worldtest] FAILED: {} desynced blocks", failedMismatches);
        client.method_1592();
    }

    private static void deleteWorldSave(Path dir) {
        if (!Files.exists(dir)) return;
        try (var stream = Files.walk(dir)) {
            stream.sorted(Comparator.reverseOrder()).forEach(p -> {
                try { Files.deleteIfExists(p); } catch (IOException ignored) {}
            });
        } catch (IOException ignored) {}
    }
}
