package fr.orbitalstrike.crater;

import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_1540;
import net.minecraft.class_1542;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2512;
import net.minecraft.class_2520;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_7871;
import net.minecraft.class_7924;

/**
 * Undo snapshot of a strike: stores the original state of each modified block
 * (first seen state only) along with block entity data.
 * Used by /orbitalstrike undo. NBT-serializable for disk persistence.
 */
public final class UndoSnapshot {
    private final UUID id;
    private final class_2960 dimension;
    private final class_2338 center;
    private final int power;
    private final long createdAtMillis;
    private final Long2ObjectOpenHashMap<class_2680> states = new Long2ObjectOpenHashMap<>();
    private final Long2ObjectOpenHashMap<class_2487> blockEntities = new Long2ObjectOpenHashMap<>();

    public UndoSnapshot(UUID id, class_2960 dimension, class_2338 center, int power, long createdAtMillis) {
        this.id = id;
        this.dimension = dimension;
        this.center = center;
        this.power = power;
        this.createdAtMillis = createdAtMillis;
    }

    public UUID id() {
        return id;
    }

    public class_2960 dimension() {
        return dimension;
    }

    public class_2338 center() {
        return center;
    }

    public int power() {
        return power;
    }

    public long createdAtMillis() {
        return createdAtMillis;
    }

    public int size() {
        return states.size();
    }

    /** Records the current state of {@code pos} if not already saved. Call before writing. */
    public void record(class_3218 world, class_2338 pos) {
        long key = pos.method_10063();
        if (states.containsKey(key)) return;
        class_2680 state = world.method_8320(pos);
        recordKnown(world, pos, key, state);
    }

    /** Fast path when the current block state has already been read from the ChunkSection. */
    public void recordFast(class_3218 world, class_2338 pos, class_2680 existingState) {
        long key = pos.method_10063();
        if (states.containsKey(key)) return;
        recordKnown(world, pos, key, existingState);
    }

    private void recordKnown(class_3218 world, class_2338 pos, long key, class_2680 state) {
        states.put(key, state);
        if (state.method_31709()) {
            class_2586 be = world.method_8321(pos);
            if (be != null) blockEntities.put(key, be.method_38243(world.method_30349()));
        }
    }

    /** Recorded positions, used to spread restoration across multiple ticks. */
    public long[] positions() {
        return states.keySet().toLongArray();
    }

    /** Restores a single block to its original state. */
    public void restore(class_3218 world, long key) {
        class_2680 state = states.get(key);
        if (state == null) return;
        class_2338 pos = class_2338.method_10092(key);
        if (!world.method_8393(pos.method_10263() >> 4, pos.method_10260() >> 4)) return;
        world.method_8544(pos);
        world.method_8652(pos, state, CraterBuilder.FLAGS);
        class_2487 nbt = blockEntities.get(key);
        if (nbt != null) {
            class_2586 be = world.method_8321(pos);
            if (be != null) {
                be.method_58690(nbt, world.method_30349());
                be.method_5431();
            }
        }
    }

    /** Removes dropped items and airborne falling debris left in the strike area. */
    public void clearLeftovers(class_3218 world) {
        double reach = CraterProfile.forPower(power).radius() * CraterShape.EJECTA_END * 1.5;
        class_238 box = new class_238(center).method_1009(reach, 128, reach);
        for (class_1297 e : world.method_8333(null, box, e -> e instanceof class_1542 || e instanceof class_1540)) {
            e.method_31472();
        }
    }

    // ------------------------------------------------------------------ NBT

    public class_2487 toNbt() {
        class_2487 root = new class_2487();
        root.method_25927("id", id);
        root.method_10582("dimension", dimension.toString());
        root.method_10544("center", center.method_10063());
        root.method_10569("power", power);
        root.method_10544("created", createdAtMillis);

        Map<class_2680, Integer> index = new HashMap<>();
        class_2499 palette = new class_2499();
        long[] positions = new long[states.size()];
        int[] indices = new int[states.size()];
        int i = 0;
        for (Long2ObjectMap.Entry<class_2680> e : states.long2ObjectEntrySet()) {
            positions[i] = e.getLongKey();
            Integer idx = index.get(e.getValue());
            if (idx == null) {
                idx = palette.size();
                index.put(e.getValue(), idx);
                palette.add(class_2512.method_10686(e.getValue()));
            }
            indices[i++] = idx;
        }
        root.method_10566("palette", palette);
        root.method_10564("positions", positions);
        root.method_10539("states", indices);

        class_2499 bes = new class_2499();
        for (Long2ObjectMap.Entry<class_2487> e : blockEntities.long2ObjectEntrySet()) {
            class_2487 entry = new class_2487();
            entry.method_10544("pos", e.getLongKey());
            entry.method_10566("data", e.getValue());
            bes.add(entry);
        }
        root.method_10566("block_entities", bes);
        return root;
    }

    public static UndoSnapshot fromNbt(class_2487 root, class_3218 world) {
        UndoSnapshot s = new UndoSnapshot(root.method_25926("id"), class_2960.method_60654(root.method_10558("dimension")),
                class_2338.method_10092(root.method_10537("center")), root.method_10550("power"), root.method_10537("created"));
        class_7871<class_2248> lookup = world.method_45448(class_7924.field_41254);
        class_2499 palette = root.method_10554("palette", class_2520.field_33260);
        List<class_2680> decoded = new ArrayList<>(palette.size());
        for (int i = 0; i < palette.size(); i++) decoded.add(class_2512.method_10681(lookup, palette.method_10602(i)));
        long[] positions = root.method_10565("positions");
        int[] indices = root.method_10561("states");
        for (int i = 0; i < positions.length && i < indices.length; i++) {
            int idx = indices[i];
            s.states.put(positions[i], idx >= 0 && idx < decoded.size() ? decoded.get(idx) : class_2246.field_10124.method_9564());
        }
        class_2499 bes = root.method_10554("block_entities", class_2520.field_33260);
        for (int i = 0; i < bes.size(); i++) {
            class_2487 entry = bes.method_10602(i);
            s.blockEntities.put(entry.method_10537("pos"), entry.method_10562("data"));
        }
        return s;
    }
}
