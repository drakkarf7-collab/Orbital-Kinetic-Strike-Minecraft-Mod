package fr.orbitalstrike.crater;

import fr.orbitalstrike.block.AshLayerBlock;
import fr.orbitalstrike.block.MoltenRockBlock;
import fr.orbitalstrike.block.TungstenBlock;
import fr.orbitalstrike.config.ModConfig;
import fr.orbitalstrike.registry.ModBlocks;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2465;
import net.minecraft.class_2680;
import net.minecraft.class_2902;
import net.minecraft.class_3218;
import net.minecraft.class_3481;
import net.minecraft.class_5819;

/**
 * Applies a crater to the world, spread across multiple ticks.
 * <p>Columns are processed from the center outward, using a per-tick <b>time budget</b>
 * (rather than a fixed block count). For each column:</p>
 * <ol>
 *   <li>bowl (terraces, central peak, molten rock), rim, or gentle talus slope;</li>
 *   <li>surface dressing around the crater: scorched zone, felled trees, ejecta blanket and rays, ash.</li>
 * </ol>
 * <p>Lava and fire are placed last to avoid cascading flow updates, followed by the spire.
 * Every modified block is first recorded in an {@link UndoSnapshot} for /orbitalstrike undo.</p>
 */
public final class CraterBuilder {
    /** Skip neighbor updates and block drops for speed and to avoid chain reactions. */
    static final int FLAGS = class_2248.field_31028 | class_2248.field_31031 | class_2248.field_31032;
    /** Check the clock every N columns (System.nanoTime is not free). */
    private static final int CLOCK_STRIDE = 16;
    /** Maximum vegetation depth scanned to locate the ground. */
    private static final int MAX_VEGETATION_SCAN = 48;
    private static final int MAX_TRUNK = 24;
    private static final int MIN_TRUNK = 3;
    private static final int MAX_EJECTA_LAYERS = 3;

    private final class_3218 world;
    private final class_2338 center;
    private final CraterShape shape;
    private final class_5819 random;
    private final ModConfig cfg;
    private final int[] offsets; // (dx, dz) pairs sorted by distance
    private int cursor = 0;

    private final List<class_2338> lavaPositions = new ArrayList<>();
    private final List<class_2338> firePositions = new ArrayList<>();
    private int finalCursor = 0;
    private boolean spirePlaced = false;
    private boolean finished = false;
    private int felledTrees = 0;
    private final int bottomY;
    private final @Nullable UndoSnapshot snapshot;
    private final class_2338.class_2339 pos = new class_2338.class_2339();

    public CraterBuilder(class_3218 world, class_2338 center, int power, ModConfig cfg, @Nullable UndoSnapshot snapshot) {
        this.world = world;
        this.center = center;
        this.cfg = cfg;
        this.snapshot = snapshot;
        this.random = class_5819.method_43049(center.method_10063() ^ world.method_8510());
        this.shape = new CraterShape(CraterProfile.forPower(power), center.method_10264(), random.method_43055());
        this.offsets = sortedOffsets(shape.scanExtent());
        this.bottomY = world.method_31607();
    }

    public CraterShape shape() {
        return shape;
    }

    public boolean isDone() {
        return finished;
    }

    public @Nullable UndoSnapshot snapshot() {
        return snapshot;
    }

    /**
     * Runs on the impact tick: carves the entire bowl, forms the rim, and immediately
     * places the monumental spire so it appears at the moment of impact.
     */
    public void impactBurst() {
        double r2 = Math.pow(shape.profile().radius() * 1.55, 2);
        while (cursor < offsets.length) {
            int dx = offsets[cursor], dz = offsets[cursor + 1];
            if ((long) dx * dx + (long) dz * dz > r2) break;
            processColumn(dx, dz);
            cursor += 2;
        }
        for (class_2338 p : lavaPositions) {
            if (isLoaded(p)) set(p, class_2246.field_10164.method_9564());
        }
        lavaPositions.clear();
        if (!spirePlaced) {
            placeSpire();
            spirePlaced = true;
        }
    }

    /** Advances crater construction for at most {@code budgetNanos} nanoseconds. */
    public void tick(long budgetNanos) {
        long deadline = System.nanoTime() + budgetNanos;
        int sinceCheck = 0;
        while (cursor < offsets.length) {
            processColumn(offsets[cursor], offsets[cursor + 1]);
            cursor += 2;
            if (++sinceCheck >= CLOCK_STRIDE) {
                sinceCheck = 0;
                if (System.nanoTime() >= deadline) return;
            }
        }

        // Final pass: remaining lava, then fire.
        int total = lavaPositions.size() + firePositions.size();
        while (finalCursor < total) {
            if (finalCursor < lavaPositions.size()) {
                class_2338 p = lavaPositions.get(finalCursor);
                if (isLoaded(p)) set(p, class_2246.field_10164.method_9564());
            } else {
                class_2338 p = firePositions.get(finalCursor - lavaPositions.size());
                if (isLoaded(p) && world.method_8320(p).method_26215()
                        && world.method_8320(p.method_10074()).method_26216(world, p.method_10074())) {
                    set(p, class_2246.field_10036.method_9564());
                }
            }
            finalCursor++;
            if (++sinceCheck >= CLOCK_STRIDE) {
                sinceCheck = 0;
                if (System.nanoTime() >= deadline) return;
            }
        }
        if (!spirePlaced) {
            placeSpire();
            spirePlaced = true;
        }
        finished = true;
    }

    /** Finishes everything immediately (server shutdown). */
    public void finishNow() {
        while (!isDone()) tick(Long.MAX_VALUE / 4);
    }

    // ------------------------------------------------------------------ writing

    /** Writes a block while preserving the original state for undo. */
    private void set(class_2338 p, class_2680 state) {
        if (snapshot != null) snapshot.record(world, p);
        world.method_8652(p, state, FLAGS);
    }

    private class_2680 get(int x, int y, int z) {
        return world.method_8320(pos.method_10103(x, y, z));
    }

    // ------------------------------------------------------------------ columns

    private void processColumn(int dx, int dz) {
        int spireGuard = shape.profile().spireRadius() + 14;
        if (spirePlaced && Math.abs(dx) <= spireGuard && Math.abs(dz) <= spireGuard) return;
        CraterShape.Column col = shape.at(dx, dz);
        int x = center.method_10263() + dx, z = center.method_10260() + dz;
        if (!world.method_8393(x >> 4, z >> 4)) return;
        int topY = world.method_8624(class_2902.class_2903.field_13202, x, z) - 1;

        switch (col.zone()) {
            case BOWL -> carveBowl(col, x, z, dx, dz, topY);
            case RIM -> buildRim(col, x, z, dx, dz, topY);
            case PLANE -> {
                int cutTo = cutTalus(col, x, z, dx, dz, topY);
                dress(col, x, z, dx, dz, Math.min(topY, cutTo));
            }
            case OUTSIDE -> dress(col, x, z, dx, dz, topY);
        }
    }

    /** Removes everything above {@code target} in the column. */
    private void raze(int x, int z, int topY, int target) {
        for (int y = topY; y > target; y--) {
            class_2680 st = get(x, y, z);
            if (st.method_26215() || st.method_27852(class_2246.field_9987)) continue;
            set(pos, class_2246.field_10124.method_9564());
        }
    }

    private void carveBowl(CraterShape.Column col, int x, int z, int dx, int dz, int topY) {
        int target = Math.max(col.surfaceY(), bottomY + 1);
        raze(x, z, topY, target);

        // If the ground is already lower (cliff, ravine), preserve the existing floor.
        int surface = Math.min(target, topY);
        double vein = shape.wallVeinStrength(dx, dz);
        for (int layer = 0; layer < 3; layer++) {
            int y = surface - layer;
            if (y <= bottomY) break;
            if (get(x, y, z).method_27852(class_2246.field_9987)) break;
            set(pos, CraterPalette.bowl(col.n(), layer, vein, random));
        }
        if (col.n() < 0.24 && random.method_43048(100) < 35) {
            // Lava moat around the central peak.
            lavaPositions.add(new class_2338(x, surface, z));
        } else if ((col.n() > 0.5 || vein > 0.78) && random.method_43048(100) < 5) {
            firePositions.add(new class_2338(x, surface + 1, z));
        }
    }

    private void buildRim(CraterShape.Column col, int x, int z, int dx, int dz, int topY) {
        int target = Math.max(col.surfaceY(), bottomY + 1);
        raze(x, z, topY, target);
        double fissure = shape.fissureStrength(dx, dz);
        // Rim: pile up ejected material and extend the fissured crust along the crest.
        for (int y = Math.max(topY + 1, bottomY + 1); y <= target; y++) {
            set(pos.method_10103(x, y, z), CraterPalette.rim(random));
        }
        class_2680 top = get(x, target, z);
        if (!top.method_26215() && !top.method_27852(class_2246.field_9987) && top.method_26227().method_15769()) {
            class_2680 dressed = CraterPalette.scorched(top, col.n(), fissure, random);
            if (dressed != top) set(pos.method_10103(x, target, z), dressed);
        }
        if (random.method_43048(100) < 4) firePositions.add(new class_2338(x, target + 1, z));
    }

    /**
     * Talus: trims terrain exceeding the allowed slope and covers the cut
     * with scree and fissured crust to avoid any sharp cliff step.
     * Returns the surface height after trimming.
     */
    private int cutTalus(CraterShape.Column col, int x, int z, int dx, int dz, int topY) {
        int allowed = col.surfaceY();
        if (topY <= allowed) return topY;
        raze(x, z, topY, allowed);
        class_2680 st = get(x, allowed, z);
        if (!st.method_26215() && !st.method_27852(class_2246.field_9987) && st.method_26227().method_15769()) {
            double fissure = shape.fissureStrength(dx, dz);
            class_2680 base = CraterPalette.talus(random);
            set(pos, fissure > 0.54 ? CraterPalette.scorched(base, col.n(), fissure, random) : base);
        }
        return allowed;
    }

    // ------------------------------------------------------------------ crater surface dressing

    /** Scorched zone, incandescent fissures, felled trees, ejecta, and ash for one column. */
    private void dress(CraterShape.Column col, int x, int z, int dx, int dz, int topY) {
        double n = col.n();
        double angle = Math.atan2(dz, dx);
        double fissure = shape.fissureStrength(dx, dz);
        boolean onFissure = fissure > 0.54;
        boolean scorch = cfg.scorch && (shape.noise(dx, dz, 1) < shape.scorchChance(n) || onFissure);
        double thickness = shape.ejectaThickness(n, angle);
        if (!scorch && thickness <= 0) return;

        // 1. Descend through vegetation down to the ground.
        int y = topY;
        class_2680 ground = null;
        for (int steps = 0; y > bottomY && steps < MAX_VEGETATION_SCAN; y--, steps++) {
            class_2680 st = get(x, y, z);
            if (st.method_26215() || st.method_27852(ModBlocks.CHARRED_LOG) || st.method_27852(ModBlocks.ASH_LAYER)) continue;
            if (st.method_26164(class_3481.field_15503)) {
                if (scorch) set(pos, class_2246.field_10124.method_9564());
                continue;
            }
            if (st.method_26164(class_3481.field_15475)) {
                boolean base = !get(x, y - 1, z).method_26164(class_3481.field_15475);
                if (base && cfg.treeFelling && n >= CraterShape.TREE_FELL_START && n < CraterShape.SCORCH_END
                        && felledTrees < cfg.maxFelledTrees && fellTree(x, y, z, dx, dz)) {
                    felledTrees++;
                } else if (scorch) {
                    set(pos.method_10103(x, y, z), charred(st));
                }
                continue;
            }
            if (st.method_27852(class_2246.field_10477) || (st.method_45474() && st.method_26227().method_15769())) {
                if (scorch) set(pos, class_2246.field_10124.method_9564());
                continue;
            }
            ground = st;
            break;
        }
        if (ground == null || !ground.method_26227().method_15769()) return;

        // 2. Scorched ground and radiating fissures.
        if (scorch) {
            class_2680 burnt = CraterPalette.scorched(ground, n, fissure, random);
            if (burnt != ground) {
                set(pos.method_10103(x, y, z), burnt);
                ground = burnt;
            }
        }
        if (!ground.method_26216(world, pos.method_10103(x, y, z))) return;

        // Leave incandescent fissures exposed so they glow across the dark crust.
        if (fissure > 0.74) return;

        // 3. Ejecta blanket: fractional thickness becomes a placement probability.
        if (thickness > 0) {
            int layers = (int) thickness;
            if (shape.noise(dx, dz, 2) < thickness - layers) layers++;
            layers = Math.min(layers, MAX_EJECTA_LAYERS);
            boolean inRay = shape.rayStrength(angle) > 0.5;
            for (int i = 0; i < layers; i++) {
                class_2680 above = get(x, y + 1, z);
                if (!above.method_26215() && !above.method_45474()) return;
                set(pos, CraterPalette.ejecta(inRay, random));
                y++;
            }
        }

        // 4. Ash layer on top.
        if (scorch && shape.noise(dx, dz, 4) < 0.35 * shape.scorchChance(n) && get(x, y + 1, z).method_26215()) {
            int ash = 1 + (shape.noise(dx, dz, 5) < 0.3 ? 1 : 0);
            set(pos, ModBlocks.ASH_LAYER.method_9564().method_11657(AshLayerBlock.LAYERS, ash));
        }
    }

    private static class_2680 charred(class_2680 log) {
        class_2680 out = ModBlocks.CHARRED_LOG.method_9564();
        return log.method_28498(class_2465.field_11459) ? out.method_11657(class_2465.field_11459, log.method_11654(class_2465.field_11459)) : out;
    }

    /**
     * Fells the tree rooted at (x, baseY, z): removes trunk and canopy, leaves a charred stump,
     * and lays the trunk flat facing away from the impact center.
     */
    private boolean fellTree(int x, int baseY, int z, int dx, int dz) {
        int height = 0;
        while (height < MAX_TRUNK && get(x, baseY + height, z).method_26164(class_3481.field_15475)) height++;
        if (height < MIN_TRUNK) return false;

        for (int i = 0; i < height; i++) set(pos.method_10103(x, baseY + i, z), class_2246.field_10124.method_9564());
        int crownY = baseY + height;
        for (int yy = crownY - 4; yy <= crownY + 3; yy++) {
            for (int ox = -3; ox <= 3; ox++) {
                for (int oz = -3; oz <= 3; oz++) {
                    if (ox == 0 && oz == 0 && yy < crownY) continue;
                    class_2680 st = get(x + ox, yy, z + oz);
                    if (st.method_26164(class_3481.field_15503) || (st.method_26164(class_3481.field_15475) && yy >= crownY - 1)) {
                        set(pos, class_2246.field_10124.method_9564());
                    }
                }
            }
        }

        boolean alongX = Math.abs(dx) >= Math.abs(dz);
        int stepX = alongX ? Integer.signum(dx) : 0;
        int stepZ = alongX ? 0 : Integer.signum(dz);
        if (stepX == 0 && stepZ == 0) stepX = 1;
        class_2680 lying = ModBlocks.CHARRED_LOG.method_9564()
                .method_11657(class_2465.field_11459, alongX ? class_2350.class_2351.field_11048 : class_2350.class_2351.field_11051);
        set(pos.method_10103(x, baseY, z), ModBlocks.CHARRED_LOG.method_9564());
        for (int i = 1; i < height; i++) {
            int px = x + stepX * i, pz = z + stepZ * i;
            if (!world.method_8393(px >> 4, pz >> 4)) break;
            int gy = world.method_8624(class_2902.class_2903.field_13203, px, pz);
            // Trunk follows the terrain, but does not climb walls or drop into holes.
            if (Math.abs(gy - baseY) > 3) break;
            class_2680 at = get(px, gy, pz);
            if (at.method_26215() || at.method_45474() || at.method_26164(class_3481.field_15503)) set(pos, lying);
        }
        return true;
    }

    // ------------------------------------------------------------------ colossal spire

    private void placeSpire() {
        if (!isLoaded(center)) return;
        CraterProfile profile = shape.profile();
        int planeY = shape.planeY();
        int floor = shape.at(0, 0).surfaceY();
        int top = Math.min(world.method_31600() - 2, planeY + profile.spireHeight());
        int base = Math.max(bottomY + 2, floor - 10);
        int shaftR = profile.spireRadius();
        int effectiveH = Math.max(32, top - planeY);
        int hotTop = planeY + Math.max(10, effectiveH / 7);
        int collarTop = hotTop + Math.max(5, effectiveH / 12);
        int finH = Math.max(24, (int) (effectiveH * 0.42));
        int finStart = Math.max(collarTop + 6, top - finH);

        placeSpireCollar(floor, shaftR);
        placeSpireShaft(base, top, planeY, hotTop, collarTop, shaftR);
        placeSpireFins(finStart, top - 3, shaftR, profile.power());
        placeSpireCrown(top, shaftR);
    }

    private void placeSpireCollar(int floor, int shaftR) {
        int outerR = shaftR + 3;
        class_2680 obsidian = class_2246.field_10540.method_9564();
        class_2680 light = class_2246.field_37572.method_9564();
        class_2680 molten0 = moltenStage(0);
        class_2338.class_2339 p = new class_2338.class_2339();
        for (int ox = -outerR; ox <= outerR; ox++) {
            for (int oz = -outerR; oz <= outerR; oz++) {
                double d = Math.hypot(ox, oz);
                if (d > outerR + 0.4 || isInShaft(ox, oz, shaftR)) continue;
                int px = center.method_10263() + ox;
                int pz = center.method_10260() + oz;
                if (!world.method_8393(px >> 4, pz >> 4)) continue;
                int maxY = d <= shaftR + 1.4 ? floor + 3 : (d <= shaftR + 2.4 ? floor + 1 : floor);
                for (int y = Math.max(bottomY + 2, floor - 2); y <= maxY; y++) {
                    class_2680 st = (y >= maxY && d <= shaftR + 1.5) ? light
                            : (d <= shaftR + 2.8 ? molten0 : obsidian);
                    setSpireBlock(p.method_10103(px, y, pz), st);
                }
            }
        }
    }

    private void placeSpireShaft(int base, int top, int planeY, int hotTop, int collarTop, int shaftR) {
        class_2680 tungsten = ModBlocks.TUNGSTEN_BLOCK.method_9564();
        class_2680 conduit = ModBlocks.THERMAL_CONDUIT.method_9564();
        class_2680 shroom = class_2246.field_22122.method_9564();
        class_2680 frog = class_2246.field_37572.method_9564();
        int midHotTop = base + (int) ((top - base) * 0.58);
        class_2338.class_2339 p = new class_2338.class_2339();
        for (int y = base; y <= top; y++) {
            int radius = y >= top - 1 ? Math.max(1, shaftR - 1) : shaftR;
            boolean segmentRing = y > collarTop && (y - collarTop) % 6 == 0;
            boolean collarBand = y == hotTop + 1 || y == collarTop;
            for (int ox = -radius; ox <= radius; ox++) {
                for (int oz = -radius; oz <= radius; oz++) {
                    if (!isInShaft(ox, oz, radius)) continue;
                    int px = center.method_10263() + ox;
                    int pz = center.method_10260() + oz;
                    if (!world.method_8393(px >> 4, pz >> 4)) continue;
                    boolean core = Math.abs(ox) <= 1 && Math.abs(oz) <= 1;
                    boolean cardinal = (ox == 0 && Math.abs(oz) == radius)
                            || (oz == 0 && Math.abs(ox) == radius);
                    boolean onEdge = Math.abs(ox) == radius || Math.abs(oz) == radius;
                    class_2680 st;
                    if (y <= hotTop) {
                        // White-hot base and core: bright core lights and molten lava.
                        if (core) st = shroom;
                        else if (cardinal) st = (y - base) % 2 == 0 ? frog : shroom;
                        else st = (y + ox + oz) % 3 == 0 ? shroom : moltenStage(0);
                    } else if (y <= collarTop) {
                        // Hot lower sleeve gradually cooling down.
                        if (core) st = moltenStage(0);
                        else if (collarBand && onEdge) st = conduit;
                        else if (cardinal) st = y % 2 == 0 ? shroom : moltenStage(0);
                        else st = (y + ox + oz) % 4 == 0 ? moltenStage(0) : tungsten;
                    } else if (y <= midHotTop) {
                        // Still-incandescent mid-shaft: hot cooling core and cardinal grooves.
                        if (core) st = (y % 3 == 0) ? moltenStage(0) : conduit;
                        else if (segmentRing && onEdge) st = moltenStage(0);
                        else if (cardinal) st = (y % 2 == 0) ? moltenStage(0) : conduit;
                        else st = tungsten;
                    } else if (core) {
                        st = conduit;
                    } else if (segmentRing && onEdge) {
                        st = cardinal ? moltenStage(0) : conduit;
                    } else if (cardinal && (y - collarTop) % 6 == 3) {
                        st = conduit;
                    } else {
                        st = tungsten;
                    }
                    setSpireBlock(p.method_10103(px, y, pz), st);
                }
            }
        }
    }

    private void placeSpireFins(int finStart, int finTop, int shaftR, int power) {
        if (finTop <= finStart) return;
        class_2680 tungsten = ModBlocks.TUNGSTEN_BLOCK.method_9564();
        class_2680 conduit = ModBlocks.THERMAL_CONDUIT.method_9564();
        class_2680 moltenEdge = moltenStage(0);
        int maxSpan = shaftR + 5 + power * 2;
        int[][] dirs = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
        class_2338.class_2339 p = new class_2338.class_2339();

        for (int y = finStart; y <= finTop; y++) {
            double ft = (double) (y - finStart) / (finTop - finStart);
            double profile = ft <= 0.72 ? (ft / 0.72) : (1.0 - 0.35 * ((ft - 0.72) / 0.28));
            int span = Math.max(shaftR + 1, shaftR + 1 + (int) Math.round((maxSpan - shaftR - 1) * profile));
            boolean ribY = (y - finStart) % 6 == 0 || y == finStart || y == finTop;

            for (int[] dir : dirs) {
                int dx = dir[0], dz = dir[1];
                int pxOrtho = -dz, pzOrtho = dx;
                for (int s = shaftR + 1; s <= span; s++) {
                    int halfThick = (s <= shaftR + (span - shaftR) / 3) ? 1 : 0;
                    for (int w = -halfThick; w <= halfThick; w++) {
                        int wx = center.method_10263() + dx * s + pxOrtho * w;
                        int wz = center.method_10260() + dz * s + pzOrtho * w;
                        if (!world.method_8393(wx >> 4, wz >> 4)) continue;
                        boolean outer = (s == span) && (w == 0);
                        boolean groove = outer || (ribY && w == 0);
                        class_2680 st = outer ? conduit : (groove ? moltenEdge : tungsten);
                        setSpireBlock(p.method_10103(wx, y, wz), st);
                    }
                }
            }
        }
    }

    private void placeSpireCrown(int top, int shaftR) {
        class_2680 tungsten = ModBlocks.TUNGSTEN_BLOCK.method_9564();
        class_2680 conduit = ModBlocks.THERMAL_CONDUIT.method_9564();
        class_2338.class_2339 p = new class_2338.class_2339();
        int[][] dirs = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
        for (int[] dir : dirs) {
            for (int s = 1; s <= shaftR; s++) {
                int px = center.method_10263() + dir[0] * s;
                int pz = center.method_10260() + dir[1] * s;
                if (world.method_8393(px >> 4, pz >> 4)) {
                    setSpireBlock(p.method_10103(px, top - 1, pz), conduit);
                }
            }
        }
        setSpireBlock(p.method_10103(center.method_10263(), top, center.method_10260()), tungsten.method_11657(TungstenBlock.SPIRE, true));
    }

    private boolean isInShaft(int ox, int oz, int radius) {
        return Math.abs(ox) <= radius && Math.abs(oz) <= radius && Math.abs(ox) + Math.abs(oz) <= radius + 1;
    }

    private static class_2680 moltenStage(int stage) {
        return ModBlocks.MOLTEN_ROCK.method_9564().method_11657(MoltenRockBlock.STAGE, stage);
    }

    private void setSpireBlock(class_2338 p, class_2680 state) {
        if (world.method_8320(p).method_27852(class_2246.field_9987)) return;
        set(p, state);
    }

    private boolean isLoaded(class_2338 p) {
        return world.method_8393(p.method_10263() >> 4, p.method_10260() >> 4);
    }

    /** All (dx, dz) pairs in the square [-e, e]^2, sorted from center outward. */
    static int[] sortedOffsets(int e) {
        int side = 2 * e + 1;
        long[] keyed = new long[side * side];
        int i = 0;
        for (int dx = -e; dx <= e; dx++) {
            for (int dz = -e; dz <= e; dz++) {
                long d2 = (long) dx * dx + (long) dz * dz;
                keyed[i++] = (d2 << 32) | ((long) (dx + 32768) << 16) | (dz + 32768);
            }
        }
        java.util.Arrays.sort(keyed);
        int[] out = new int[keyed.length * 2];
        for (int k = 0; k < keyed.length; k++) {
            out[2 * k] = (int) ((keyed[k] >>> 16) & 0xFFFF) - 32768;
            out[2 * k + 1] = (int) (keyed[k] & 0xFFFF) - 32768;
        }
        return out;
    }
}
