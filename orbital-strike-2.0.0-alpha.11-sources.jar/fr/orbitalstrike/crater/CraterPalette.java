package fr.orbitalstrike.crater;

import fr.orbitalstrike.block.MoltenRockBlock;
import fr.orbitalstrike.registry.ModBlocks;
import net.minecraft.class_2246;
import net.minecraft.class_2680;
import net.minecraft.class_3481;
import net.minecraft.class_5819;

/**
 * Material selection based on position inside and around the crater.
 * n = normalized distance from center (0 = center, 1 = bowl edge),
 * layer = 0 for surface, 1..2 for underlying layers.
 */
public final class CraterPalette {
    /** Below this normalized distance, sand vitrifies into glass. */
    private static final double VITRIFY_END = 1.5;

    private CraterPalette() {}

    private static class_2680 molten(int stage) {
        return ModBlocks.MOLTEN_ROCK.method_9564().method_11657(MoltenRockBlock.STAGE, stage);
    }

    public static class_2680 bowl(double n, int layer, class_5819 rnd) {
        return bowl(n, layer, 0.0, rnd);
    }

    public static class_2680 bowl(double n, int layer, double vein, class_5819 rnd) {
        int roll = rnd.method_43048(100);
        if (layer == 0 && vein > 0.62) {
            if (vein > 0.80) return molten(0);
            return rnd.method_43056() ? molten(1) : class_2246.field_10092.method_9564();
        }
        if (layer == 1 && vein > 0.72) {
            return class_2246.field_10092.method_9564();
        }
        if (n < 0.2) {
            // Core: molten rock.
            if (layer == 0) return roll < 75 ? molten(0) : (roll < 92 ? molten(1) : class_2246.field_10092.method_9564());
            return roll < 60 ? class_2246.field_10092.method_9564() : class_2246.field_23869.method_9564();
        }
        if (n < 0.38) {
            // Inner ring: incandescent and hot rock mixed with blackstone and obsidian.
            if (layer == 0) {
                if (roll < 35) return molten(1);
                if (roll < 62) return molten(2);
                if (roll < 82) return class_2246.field_10092.method_9564();
                if (roll < 92) return class_2246.field_23869.method_9564();
                return class_2246.field_10540.method_9564();
            }
            return roll < 55 ? class_2246.field_23869.method_9564() : class_2246.field_22091.method_9564();
        }
        if (n < 0.7) {
            if (roll < 42) return class_2246.field_22091.method_9564();
            if (roll < 72) return class_2246.field_23869.method_9564();
            if (roll < 84) return class_2246.field_10540.method_9564();
            if (roll < 90 && layer == 0) return molten(2);
            return class_2246.field_29032.method_9564();
        }
        // Terraces: fractured and blackened rock.
        if (layer > 0) return roll < 55 ? class_2246.field_23869.method_9564() : class_2246.field_28888.method_9564();
        if (roll < 35) return class_2246.field_23869.method_9564();
        if (roll < 60) return class_2246.field_29031.method_9564();
        if (roll < 82) return class_2246.field_29032.method_9564();
        return class_2246.field_27165.method_9564();
    }

    public static class_2680 rim(class_5819 rnd) {
        int roll = rnd.method_43048(100);
        if (roll < 40) return class_2246.field_27165.method_9564();
        if (roll < 65) return class_2246.field_10445.method_9564();
        if (roll < 85) return class_2246.field_10253.method_9564();
        return class_2246.field_29031.method_9564();
    }

    /** Scree covering the trimmed talus slope. */
    public static class_2680 talus(class_5819 rnd) {
        int roll = rnd.method_43048(100);
        if (roll < 45) return class_2246.field_10253.method_9564();
        if (roll < 70) return class_2246.field_10255.method_9564();
        if (roll < 88) return class_2246.field_27165.method_9564();
        return class_2246.field_10445.method_9564();
    }

    /** Ejecta blanket debris. Within a ray, material is noticeably brighter. */
    public static class_2680 ejecta(boolean inRay, class_5819 rnd) {
        int roll = rnd.method_43048(100);
        if (inRay) {
            if (roll < 50) return class_2246.field_27114.method_9564();
            if (roll < 80) return class_2246.field_10508.method_9564();
            return class_2246.field_27165.method_9564();
        }
        if (roll < 35) return class_2246.field_10253.method_9564();
        if (roll < 60) return class_2246.field_27165.method_9564();
        if (roll < 80) return class_2246.field_10255.method_9564();
        return class_2246.field_10445.method_9564();
    }

    /**
     * Scorched version of a ground block. Returns the same state if unchanged.
     */
    public static class_2680 scorched(class_2680 ground, double n, class_5819 rnd) {
        return scorched(ground, n, 0.0, rnd);
    }

    /**
     * Scorched and fissured version of a ground block around the crater.
     * Intense fissures become molten rock or magma bordered by obsidian.
     */
    public static class_2680 scorched(class_2680 ground, double n, double fissure, class_5819 rnd) {
        if (ground.method_26164(class_3481.field_15467)) return class_2246.field_10382.method_9564();
        if (ground.method_27852(class_2246.field_10491) || ground.method_27852(class_2246.field_27879)) {
            ground = class_2246.field_10253.method_9564();
        }
        if (!isScorchableGround(ground)) return ground;

        if (fissure > 0.72) {
            if (fissure > 0.85) return molten(0);
            int r = rnd.method_43048(100);
            if (r < 42) return ModBlocks.THERMAL_CONDUIT.method_9564();
            return r < 76 ? molten(1) : class_2246.field_10092.method_9564();
        }
        if (fissure > 0.50) {
            int r = rnd.method_43048(100);
            if (r < 22) return ModBlocks.THERMAL_CONDUIT.method_9564();
            return r < 60 ? class_2246.field_23869.method_9564() : class_2246.field_10540.method_9564();
        }

        if (ground.method_26164(class_3481.field_15466) && n < VITRIFY_END) {
            int r = rnd.method_43048(100);
            if (r < 32) return class_2246.field_10073.method_9564();
            if (r < 55) return class_2246.field_23869.method_9564();
            return ground;
        }

        if (n < 1.85) {
            int roll = rnd.method_43048(100);
            if (roll < 8) return ModBlocks.THERMAL_CONDUIT.method_9564();
            if (roll < 42) return class_2246.field_23869.method_9564();
            if (roll < 64) return class_2246.field_23873.method_9564();
            if (roll < 82) return class_2246.field_29032.method_9564();
            if (roll < 94) return class_2246.field_29031.method_9564();
            return class_2246.field_27165.method_9564();
        }

        double heat = Math.max(0.0, Math.min(1.0, (2.5 - n) / 0.85));
        if (rnd.method_43058() < heat * 0.65) {
            int roll = rnd.method_43048(100);
            if (roll < 40) return class_2246.field_23869.method_9564();
            if (roll < 75) return class_2246.field_29032.method_9564();
            return class_2246.field_29031.method_9564();
        }
        if (ground.method_27852(class_2246.field_10219) || ground.method_27852(class_2246.field_10520) || ground.method_27852(class_2246.field_10402)
                || ground.method_27852(class_2246.field_10194) || ground.method_27852(class_2246.field_10362) || ground.method_27852(class_2246.field_28681)) {
            return rnd.method_43048(100) < 80 ? class_2246.field_10253.method_9564() : class_2246.field_10566.method_9564();
        }
        return ground;
    }

    private static boolean isScorchableGround(class_2680 ground) {
        if (ground.method_27852(class_2246.field_9987) || ground.method_27852(class_2246.field_10540)
                || ground.method_27852(ModBlocks.TUNGSTEN_BLOCK) || ground.method_27852(ModBlocks.THERMAL_CONDUIT)
                || ground.method_27852(ModBlocks.MOLTEN_ROCK) || ground.method_31709()) {
            return false;
        }
        return ground.method_27852(class_2246.field_10219) || ground.method_27852(class_2246.field_10520) || ground.method_27852(class_2246.field_10402)
                || ground.method_27852(class_2246.field_10194) || ground.method_27852(class_2246.field_10362) || ground.method_27852(class_2246.field_28681)
                || ground.method_27852(class_2246.field_10566) || ground.method_27852(class_2246.field_10253) || ground.method_27852(class_2246.field_28685)
                || ground.method_27852(class_2246.field_37576) || ground.method_27852(class_2246.field_10460) || ground.method_26164(class_3481.field_15466)
                || ground.method_27852(class_2246.field_10255) || ground.method_27852(class_2246.field_10340) || ground.method_27852(class_2246.field_28888)
                || ground.method_27852(class_2246.field_10115) || ground.method_27852(class_2246.field_10508) || ground.method_27852(class_2246.field_10474)
                || ground.method_27852(class_2246.field_27165) || ground.method_27852(class_2246.field_10445) || ground.method_27852(class_2246.field_29031)
                || ground.method_27852(class_2246.field_9979) || ground.method_27852(class_2246.field_10344) || ground.method_27852(class_2246.field_10415)
                || ground.method_27852(class_2246.field_22091) || ground.method_27852(class_2246.field_29032) || ground.method_27852(class_2246.field_23869);
    }
}
