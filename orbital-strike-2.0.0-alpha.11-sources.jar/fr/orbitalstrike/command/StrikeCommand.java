package fr.orbitalstrike.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import fr.orbitalstrike.config.ConfigManager;
import fr.orbitalstrike.cooldown.CooldownStore;
import fr.orbitalstrike.crater.UndoSnapshot;
import fr.orbitalstrike.crater.UndoStore;
import fr.orbitalstrike.network.ModNetworking;
import fr.orbitalstrike.skill.SkillContext;
import fr.orbitalstrike.strike.CinematicMode;
import fr.orbitalstrike.strike.StrikeLog;
import fr.orbitalstrike.strike.StrikeManager;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2186;
import net.minecraft.class_2262;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

/**
 * Operator commands (permission level 2):
 * <pre>
 * /orbitalstrike strike &lt;pos&gt; [power]   immediate strike without cinematic
 * /orbitalstrike resetcooldown [player]
 * /orbitalstrike undo [id]               restores terrain prior to the latest (or matching) strike
 * /orbitalstrike log                     lists recent strikes
 * /orbitalstrike reload
 * </pre>
 */
public final class StrikeCommand {
    private StrikeCommand() {}

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(class_2170.method_9247("orbitalstrike")
                .requires(src -> src.method_9259(2))
                .then(class_2170.method_9247("strike")
                        .then(class_2170.method_9244("pos", class_2262.method_9698())
                                .executes(ctx -> strike(ctx, ConfigManager.get().defaultPower))
                                .then(class_2170.method_9244("power", IntegerArgumentType.integer(1, 5))
                                        .executes(ctx -> strike(ctx, IntegerArgumentType.getInteger(ctx, "power"))))))
                .then(class_2170.method_9247("resetcooldown")
                        .executes(ctx -> reset(ctx, ctx.getSource().method_9207()))
                        .then(class_2170.method_9244("player", class_2186.method_9305())
                                .executes(ctx -> reset(ctx, class_2186.method_9315(ctx, "player")))))
                .then(class_2170.method_9247("undo")
                        .executes(ctx -> undo(ctx, null))
                        .then(class_2170.method_9244("id", StringArgumentType.word())
                                .executes(ctx -> undo(ctx, StringArgumentType.getString(ctx, "id")))))
                .then(class_2170.method_9247("log").executes(StrikeCommand::log))
                .then(class_2170.method_9247("reload")
                        .executes(ctx -> {
                            ConfigManager.load();
                            ctx.getSource().method_9226(() -> class_2561.method_43471("command.orbital_strike.reloaded"), true);
                            return 1;
                        })));
    }

    private static int strike(CommandContext<class_2168> ctx, int power) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        class_2168 src = ctx.getSource();
        class_2338 pos = class_2262.method_9696(ctx, "pos");
        StrikeManager.start(new SkillContext(null, src.method_9225(), pos, power, 1.0f, CinematicMode.OFF));
        src.method_9226(() -> class_2561.method_43469("command.orbital_strike.strike", pos.method_23854(), power), true);
        return 1;
    }

    private static int undo(CommandContext<class_2168> ctx, String idPrefix) {
        class_2168 src = ctx.getSource();
        UndoSnapshot snapshot = UndoStore.find(src.method_9225(), idPrefix);
        if (snapshot == null) {
            src.method_9213(class_2561.method_43471("command.orbital_strike.undo.none"));
            return 0;
        }
        if (!snapshot.dimension().equals(src.method_9225().method_27983().method_29177())) {
            src.method_9213(class_2561.method_43469("command.orbital_strike.undo.wrong_dimension", snapshot.dimension().toString()));
            return 0;
        }
        if (StrikeManager.activeCount() > 0) {
            src.method_9213(class_2561.method_43471("command.orbital_strike.undo.busy"));
            return 0;
        }
        int blocks = UndoStore.begin(src.method_9225(), snapshot);
        String at = snapshot.center().method_23854();
        src.method_9226(() -> class_2561.method_43469("command.orbital_strike.undo.started", blocks, at), true);
        return blocks;
    }

    private static int log(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();
        var entries = StrikeLog.recent();
        if (entries.isEmpty()) {
            src.method_9226(() -> class_2561.method_43471("command.orbital_strike.log.empty"), false);
            return 0;
        }
        for (StrikeLog.Entry e : entries) src.method_9226(() -> class_2561.method_43470(e.line()), false);
        return entries.size();
    }

    private static int reset(CommandContext<class_2168> ctx, class_3222 player) {
        CooldownStore.reset(player);
        ModNetworking.syncCooldown(player);
        ctx.getSource().method_9226(() -> class_2561.method_43469("command.orbital_strike.reset", player.method_5476()), true);
        return 1;
    }
}
