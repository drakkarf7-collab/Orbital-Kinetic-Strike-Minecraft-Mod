package fr.orbitalstrike.network;

import fr.orbitalstrike.OrbitalStrike;
import java.util.UUID;
import net.minecraft.class_2338;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/**
 * All mod network payloads.
 * Codecs are hand-written (PacketCodec.of) to remain simple and explicit.
 */
public final class Payloads {
    private Payloads() {}

    private static <T extends class_8710> class_8710.class_9154<T> id(String name) {
        return new class_8710.class_9154<>(OrbitalStrike.id(name));
    }

    // ---------------------------------------------------------------- C2S

    /** Player requests a strike on {@code target}. All inputs are revalidated server-side. */
    public record RequestStrike(class_2338 target, int power, float speed, int mode) implements class_8710 {
        public static final class_9154<RequestStrike> ID = id("request_strike");
        public static final class_9139<class_9129, RequestStrike> CODEC = class_9139.method_56438(
                (v, buf) -> {
                    buf.method_10807(v.target);
                    buf.method_10804(v.power);
                    buf.method_52941(v.speed);
                    buf.method_10804(v.mode);
                },
                buf -> new RequestStrike(buf.method_10811(), buf.method_10816(), buf.readFloat(), buf.method_10816()));

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return ID;
        }
    }

    // ---------------------------------------------------------------- S2C

    /** Start of a strike phase. {@code cinematic}: whether this recipient should play the cinematic. */
    public record Phase(UUID strikeId, int phase, int durationTicks, class_2338 target, int power,
                        boolean cinematic, boolean owner) implements class_8710 {
        public static final class_9154<Phase> ID = id("phase");
        public static final class_9139<class_9129, Phase> CODEC = class_9139.method_56438(
                (v, buf) -> {
                    buf.method_10797(v.strikeId);
                    buf.method_10804(v.phase);
                    buf.method_10804(v.durationTicks);
                    buf.method_10807(v.target);
                    buf.method_10804(v.power);
                    buf.method_52964(v.cinematic);
                    buf.method_52964(v.owner);
                },
                buf -> new Phase(buf.method_10790(), buf.method_10816(), buf.method_10816(), buf.method_10811(),
                        buf.method_10816(), buf.readBoolean(), buf.readBoolean()));

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return ID;
        }
    }

    /** The kinetic rod has just hit the ground. */
    public record Impact(UUID strikeId, double x, double y, double z, float radius, int power) implements class_8710 {
        public static final class_9154<Impact> ID = id("impact");
        public static final class_9139<class_9129, Impact> CODEC = class_9139.method_56438(
                (v, buf) -> {
                    buf.method_10797(v.strikeId);
                    buf.method_52940(v.x);
                    buf.method_52940(v.y);
                    buf.method_52940(v.z);
                    buf.method_52941(v.radius);
                    buf.method_10804(v.power);
                },
                buf -> new Impact(buf.method_10790(), buf.readDouble(), buf.readDouble(), buf.readDouble(),
                        buf.readFloat(), buf.method_10816()));

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return ID;
        }
    }

    /** The rod streaks across the sky from {@code from} to {@code to}, visible to all players. */
    public record SkyStreak(UUID strikeId, double fromX, double fromY, double fromZ, double toX, double toY, double toZ,
                            int durationTicks) implements class_8710 {
        public static final class_9154<SkyStreak> ID = id("sky_streak");
        public static final class_9139<class_9129, SkyStreak> CODEC = class_9139.method_56438(
                (v, buf) -> {
                    buf.method_10797(v.strikeId);
                    buf.method_52940(v.fromX);
                    buf.method_52940(v.fromY);
                    buf.method_52940(v.fromZ);
                    buf.method_52940(v.toX);
                    buf.method_52940(v.toY);
                    buf.method_52940(v.toZ);
                    buf.method_10804(v.durationTicks);
                },
                buf -> new SkyStreak(buf.method_10790(), buf.readDouble(), buf.readDouble(), buf.readDouble(),
                        buf.readDouble(), buf.readDouble(), buf.readDouble(), buf.method_10816()));

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return ID;
        }
    }

    /** Start of the shockwave. */
    public record Shockwave(UUID strikeId, double x, double y, double z, float startRadius, float endRadius,
                            int durationTicks) implements class_8710 {
        public static final class_9154<Shockwave> ID = id("shockwave");
        public static final class_9139<class_9129, Shockwave> CODEC = class_9139.method_56438(
                (v, buf) -> {
                    buf.method_10797(v.strikeId);
                    buf.method_52940(v.x);
                    buf.method_52940(v.y);
                    buf.method_52940(v.z);
                    buf.method_52941(v.startRadius);
                    buf.method_52941(v.endRadius);
                    buf.method_10804(v.durationTicks);
                },
                buf -> new Shockwave(buf.method_10790(), buf.readDouble(), buf.readDouble(), buf.readDouble(),
                        buf.readFloat(), buf.readFloat(), buf.method_10816()));

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return ID;
        }
    }

    /** Remaining cooldown and server limits for the menu UI. */
    public record CooldownSync(int remainingTicks, int totalTicks, int maxRange, int maxPower) implements class_8710 {
        public static final class_9154<CooldownSync> ID = id("cooldown_sync");
        public static final class_9139<class_9129, CooldownSync> CODEC = class_9139.method_56438(
                (v, buf) -> {
                    buf.method_10804(v.remainingTicks);
                    buf.method_10804(v.totalTicks);
                    buf.method_10804(v.maxRange);
                    buf.method_10804(v.maxPower);
                },
                buf -> new CooldownSync(buf.method_10816(), buf.method_10816(), buf.method_10816(), buf.method_10816()));

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return ID;
        }
    }
}
