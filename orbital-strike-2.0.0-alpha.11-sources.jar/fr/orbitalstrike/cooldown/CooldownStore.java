package fr.orbitalstrike.cooldown;

import fr.orbitalstrike.registry.ModAttachments;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

/**
 * Persistent per-player cooldown (Fabric Data Attachment).
 * Stores the overworld tick when the cooldown expires: since it is saved
 * with the world, the cooldown survives disconnects and server restarts.
 */
@SuppressWarnings("UnstableApiUsage")
public final class CooldownStore {
    private CooldownStore() {}

    private static long now(class_3222 player) {
        return player.method_5682().method_30002().method_8510();
    }

    /** Remaining ticks (0 if ready). */
    public static long remaining(class_3222 player, class_2960 skill) {
        Map<String, Long> map = player.getAttachedOrElse(ModAttachments.COOLDOWNS, Map.of());
        Long end = map.get(skill.toString());
        if (end == null) return 0;
        return Math.max(0, end - now(player));
    }

    public static void start(class_3222 player, class_2960 skill, int ticks) {
        Map<String, Long> map = new HashMap<>(player.getAttachedOrElse(ModAttachments.COOLDOWNS, Map.of()));
        map.put(skill.toString(), now(player) + ticks);
        player.setAttached(ModAttachments.COOLDOWNS, map);
    }

    public static void reset(class_3222 player) {
        player.removeAttached(ModAttachments.COOLDOWNS);
    }
}
